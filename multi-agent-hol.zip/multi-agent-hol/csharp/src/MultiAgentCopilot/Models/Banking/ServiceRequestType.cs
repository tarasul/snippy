﻿namespace  MultiAgentCopilot.Models.Banking
{
    public enum ServiceRequestType
    {
        Complaint = 0,
        FundTransfer = 1,
        Fulfilment = 2,
        TeleBankerCallBack = 3
    }
}
