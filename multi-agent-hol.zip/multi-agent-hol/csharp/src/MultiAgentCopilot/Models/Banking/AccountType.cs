﻿
namespace MultiAgentCopilot.Models.Banking
{
    public enum AccountType
    {
        Savings=0,
        CreditCard=1,
        Locker=2
    }
}
