﻿using Microsoft.Extensions.VectorData;

namespace MultiAgentCopilot.Models.Banking
{
    public class OfferTerm
    {
       

    }

}
