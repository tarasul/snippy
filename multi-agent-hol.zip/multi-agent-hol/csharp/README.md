# Semantic Kernel Agents Workshop

Navigate to the [Semantic Kernel Csharp Workshop](./csharp/workshop/Module-00.md)
