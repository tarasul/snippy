<#
  .SYNOPSIS
  Compiles assessment data and runs readiness checks for IIS sites

  .DESCRIPTION
  Compiles assessment data and runs readiness checks on the specified sites from 
  the local IIS configuration.

  .PARAMETER ServerName
  The name or IP of the target web server if not running locally.
  Target web server must be configured to allow remote remote PowerShell.
  More information on setting up remote powershell: https://docs.microsoft.com/en-us/powershell/module/microsoft.powershell.core/about/about_remote_requirements?view=powershell-7.1

  .PARAMETER ServerCreds
  PSCredentials for the connection to target web server if not running locally, such as
  created using Get-Credential. The user must have administrator access on target machine.

  .PARAMETER ReadinessResultsOutputPath
  Specifies the path to output the assessment results

  .PARAMETER OverwriteReadinessResults
  Overwrites existing readiness results file with the same name
  without notifying the user.

  .OUTPUTS
  Get-SiteReadiness.ps1 will output the json string readiness results which are saved to ReadinessResultsOutputPath

  .EXAMPLE
  C:\PS> $ReadinessResultsPath = .\Get-SiteReadiness 

  .EXAMPLE
  C:\PS> .\Get-SiteReadiness -ReadinessResultsOutputPath .\CustomPath_ReadinessResults.json

  .EXAMPLE
  C:\PS> .\Get-SiteReadiness -ServerName MyWebServer -ServerCreds $credForMyWebServer
#>

#Requires -Version 4.0
#Requires -RunAsAdministrator
[CmdletBinding(DefaultParameterSetName = "Local")]
param(
    [Parameter(Mandatory, ParameterSetName = "Remote")]
    [string]$ServerName,

    [Parameter(Mandatory, ParameterSetName = "Remote")]
    [PSCredential]$ServerCreds,

    [Parameter()]
    [string]$ReadinessResultsOutputPath,

    [Parameter()]
    [switch]$OverwriteReadinessResults
)
Import-Module (Join-Path $PSScriptRoot "MigrationHelperFunctions.psm1")

$ScriptConfig = Get-ScriptConfig
$ReadinessResultsPath = $ScriptConfig.DefaultReadinessResultsFilePath
$AssessedSites = New-Object System.Collections.ArrayList 

Send-TelemetryEventIfEnabled -TelemetryTitle "Get-SiteReadiness.ps1" -EventName "Started script" -EventType "action" -ErrorAction SilentlyContinue
#storing results at the path given by user
if ($ReadinessResultsOutputPath) {
    $ReadinessResultsPath = $ReadinessResultsOutputPath
}

if ((Test-Path $ReadinessResultsPath) -and !$OverwriteReadinessResults) {
    Write-HostError -Message  "$ReadinessResultsPath already exists. Use -OverwriteReadinessResults to overwrite $ReadinessResultsPath"
    exit 1
}  

$SiteList = New-Object System.Collections.ArrayList

try {   
    [System.Reflection.Assembly]::LoadWithPartialName('System.Windows.Forms') | Out-Null
    $CheckResxFile = (Join-Path $PSScriptRoot "WebAppCheckResources.resx")
    $CheckResourceSet = New-Object -TypeName 'System.Resources.ResXResourceSet' -ArgumentList $CheckResxFile
} catch {
    $ExceptionData = Get-ExceptionData -Exception $_.Exception
    Send-TelemetryEventIfEnabled -TelemetryTitle "Get-SiteReadiness.ps1" -EventName "Exception getting ResXResourceSet" -ExceptionData $ExceptionData -EventType "error" -ErrorAction SilentlyContinue
    Write-HostError -Message "Error in getting check description strings : $($_.Exception.Message)"    
}

try {  
    Write-HostInfo -Message "Scanning for site readiness/compatibility..."      
    $discoveryScript = Join-Path $PSScriptRoot "IISDiscovery.ps1"
    if($ServerName) {
        Send-TelemetryEventIfEnabled -TelemetryTitle "Get-SiteReadiness.ps1" -EventName "Discovery type" -EventMessage "Remote" -EventType "info" -ErrorAction SilentlyContinue
        try {       
            $dataString = Invoke-Command -FilePath $discoveryScript -ArgumentList $true -ComputerName $ServerName -Credential $ServerCreds -ErrorVariable invokeError -ErrorAction SilentlyContinue                         
            if($invokeError) {
                Send-TelemetryEventIfEnabled -TelemetryTitle "Get-SiteReadiness.ps1" -EventName "Error getting remote readiness results" -EventMessage "invoke" -EventType "error" -ErrorAction SilentlyContinue
                Write-HostError -Message "Error getting remote readiness data: $($invokeError[0])" 
                exit 1
            }
        } catch {
            $ExceptionData = Get-ExceptionData -Exception $_.Exception   
            Send-TelemetryEventIfEnabled -TelemetryTitle "Get-SiteReadiness.ps1" -EventName "Error getting remote readiness results" -EventMessage "exception" -ExceptionData $ExceptionData -EventType "error" -ErrorAction SilentlyContinue
            Write-HostError -Message "Error getting remote readiness data: $($_.Exception.Message)"
            exit 1
        }
    } else {    
        Send-TelemetryEventIfEnabled -TelemetryTitle "Get-SiteReadiness.ps1" -EventName "Discovery type" -EventMessage "Local" -EventType "info" -ErrorAction SilentlyContinue      
        $dataString = &($discoveryScript) -aggressiveBlocking $true
    }

    try {
        $discoveryAndAssessmentData = $dataString | ConvertFrom-Json
        if($discoveryAndAssessmentData.error) {
            Send-TelemetryEventIfEnabled -TelemetryTitle "Get-SiteReadiness.ps1" -EventName "Discovery Error" -EventMessage $discoveryAndAssessmentData.error.errorId -EventType "error" -ErrorAction SilentlyContinue
            Write-HostError -Message "Error occurred retrieving IIS server data, issue was: $($discoveryAndAssessmentData.error.errorId): $($discoveryAndAssessmentData.error.detailedMessage)"
            exit 1
        }
    } catch {
        Write-HostError -Message "Error with reading readiness data. Data was in unexpected format. $($_.Exception.Message)"
        exit 1
    }
    
    #Loop through and process each readiness report in the assessment from iisConfigAssistant
    foreach ($Report in $discoveryAndAssessmentData.readinessData.IISSites) {
        $WarningChecks = New-Object System.Collections.ArrayList
        $FailedChecks = New-Object System.Collections.ArrayList
        $FatalErrorFound = $false
        
        
        Write-HostInfo -Message "Report generated for $($Report.webAppName)" 
    
        foreach ($Check in $Report.checks) {            
            $detailsString = ""; 
            if($Check.PSObject.Properties.Name -contains "Details") {
                if($Check.Details.Count -gt 0) { 
                    $detailsString = $Check.Details[0]; 
                }
                $Check.PSObject.Properties.Remove('Details');
            }                           
            if(-not($Check.PSObject.Properties.Name -contains "detailsString")) {                                   
                Add-Member -InputObject $Check -MemberType NoteProperty -Name detailsString -Value $detailsString                               
            }
            
            #rename "result" to "Status"
            $Check | Add-Member -MemberType NoteProperty -Name Status -Value $Check.result
            $Check.PSObject.Properties.Remove('result')
            
            if($CheckResourceSet) {         
                $Check | Add-Member -MemberType NoteProperty -Name Description -Value $CheckResourceSet.GetString("$($Check.IssueId)Title")
                $formattedDetailsMessage = $CheckResourceSet.GetString("$($Check.IssueId)Description") -f $detailsString
                $Check | Add-Member -MemberType NoteProperty -Name Details -Value $formattedDetailsMessage 
                $Check | Add-Member -MemberType NoteProperty -Name Recommendation -Value $CheckResourceSet.GetString("$($Check.IssueId)Recommendation")
                $Check | Add-Member -MemberType NoteProperty -Name MoreInfoLink -Value $CheckResourceSet.GetString("$($Check.IssueId)MoreInformationLink")
            }
                        
            if ($Check.Status -eq "Warn") {
                [void]$WarningChecks.Add($Check)
                Send-TelemetryEventIfEnabled -TelemetryTitle "Get-SiteReadiness.ps1" -EventName "Warning Check" -EventType "info" -EventMessage "$($Check.IssueId)" -ErrorAction SilentlyContinue
            }
            else { # only non-passing checks included in results
                [void]$FailedChecks.Add($Check)
                Send-TelemetryEventIfEnabled -TelemetryTitle "Get-SiteReadiness.ps1" -EventName "Failed Check" -EventType "info" -EventMessage "$($Check.IssueId)" -ErrorAction SilentlyContinue
            }
        }

        if ($WarningChecks) {
            Write-HostWarn -Message "Warnings for $($Report.webAppName): $($WarningChecks.IssueId -join  ',')"
        }    
        if ($FailedChecks.Count -eq 0) {
            Write-HostInfo -Message "$($Report.webAppName): No Blocking issues found and the site is ready for migration to Azure!"
            if($WarningChecks) { 
                Send-TelemetryEventIfEnabled -TelemetryTitle "Get-SiteReadiness.ps1" -EventName "Overall Status" -EventMessage "ConditionallyReady" -EventType "info" -ErrorAction SilentlyContinue
            } else {
                Send-TelemetryEventIfEnabled -TelemetryTitle "Get-SiteReadiness.ps1" -EventName "Overall Status" -EventMessage "Ready" -EventType "info" -ErrorAction SilentlyContinue
            }
        }
        else {
            $FailedFatalChecksString = ""
            $FatalChecks = $ScriptConfig.FatalChecks            

            #finding if any failed checks are fatal 
            # fatal checks are configured in ScriptConfig.json and indicate migration is not possible (i.e. errors will occur during packaging/deploying steps)
            foreach ($FailedCheck in $FailedChecks) {
                if ($FatalChecks.Contains($FailedCheck.IssueId)) {
                    $FailedFatalChecksString += $FailedCheck.IssueId + ", "
                    $FatalErrorFound = $true                    
                }
            }
            
            Write-HostWarn -Message "Failed Checks for $($Report.webAppName) : $($FailedChecks.IssueId -join  ',')"
            
            if ($FatalErrorFound) {
                $FailedFatalChecksString = $FailedFatalChecksString.TrimEnd(',')
                Write-HostWarn -Message "FATAL errors detected in $($Report.webAppName) : $FailedFatalChecksString"
                Write-HostWarn -Message "These failures prevent migration using this tooling. You will not be able to migrate this site until the checks resulting in fatal errors are fixed"   
                Send-TelemetryEventIfEnabled -TelemetryTitle "Get-SiteReadiness.ps1" -EventName "Overall Status" -EventMessage "Blocked" -EventType "info" -ErrorAction SilentlyContinue
            } else {
                Send-TelemetryEventIfEnabled -TelemetryTitle "Get-SiteReadiness.ps1" -EventName "Overall Status" -EventMessage "NotReady" -EventType "info" -ErrorAction SilentlyContinue
            }
        }           
        
        $discoveryData = $discoveryAndAssessmentData.discoveryData.IISSites | Where-Object {$_.webAppName -eq $Report.webAppName} | Select-Object -First 1
        $appPoolInfo = $discoveryData.applications | Where-Object {$_.path -eq "/"} | Select-Object -First 1

        $Site = New-Object PSObject
        Add-Member -InputObject $Site -MemberType NoteProperty -Name SiteName -Value $Report.webAppName
        #check information
        Add-Member -InputObject $Site -MemberType NoteProperty -Name FatalErrorFound -Value $FatalErrorFound
        Add-Member -InputObject $Site -MemberType NoteProperty -Name FailedChecks -Value $FailedChecks
        Add-Member -InputObject $Site -MemberType NoteProperty -Name WarningChecks -Value $WarningChecks
        #app pool settings
        Add-Member -InputObject $Site -MemberType NoteProperty -Name ManagedPipelineMode -Value $appPoolInfo.managedPipelineMode
        Add-Member -InputObject $Site -MemberType NoteProperty -Name Is32Bit -Value $appPoolInfo.enable32BitAppOnWin64
        Add-Member -InputObject $Site -MemberType NoteProperty -Name NetFrameworkVersion -Value $appPoolInfo.managedRuntimeVersion
        #vdir configuration
        Add-Member -InputObject $Site -MemberType NoteProperty -Name VirtualApplications -Value $discoveryData.virtualApplications
        
        [void]$AssessedSites.Add($Site)

        #next line for logical spacing between multiple sites
        Write-Host "" 
    }    

    try
    {
        $AssessedSites | ConvertTo-Json -Depth 10 | Out-File (New-Item -Path $ReadinessResultsPath -ItemType "file" -ErrorAction Stop -Force)
    } catch {
        Write-HostError -Message "Error outputting readiness results files: $($_.Exception.Message)" 
        Send-TelemetryEventIfEnabled -TelemetryTitle "Get-SiteReadiness.ps1" -EventName "Error in creating readiness results file" -EventType "error" -ErrorAction SilentlyContinue
        exit 1
    }
    
Write-HostInfo -Message "Readiness checks complete. Readiness results outputted to $ReadinessResultsPath"
return $ReadinessResultsPath  

} catch {
    $ExceptionData = Get-ExceptionData -Exception $_.Exception
    Write-HostError -Message "Error in generating Readiness results : $($_.Exception.Message)"
    Send-TelemetryEventIfEnabled -TelemetryTitle "Get-SiteReadiness.ps1" -EventName "Error in generating Readiness results" -ExceptionData $ExceptionData -EventType "error" -ErrorAction SilentlyContinue
}

Send-TelemetryEventIfEnabled -TelemetryTitle "Get-SiteReadiness.ps1" -EventName "Script end" -EventType "action" -ErrorAction SilentlyContinue




# SIG # Begin signature block
# MIIoKAYJKoZIhvcNAQcCoIIoGTCCKBUCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCAvhSXVU7DmEGda
# 1athEYR7xZ8Cn37E4d19tfVmqiv8I6CCDXYwggX0MIID3KADAgECAhMzAAADrzBA
# DkyjTQVBAAAAAAOvMA0GCSqGSIb3DQEBCwUAMH4xCzAJBgNVBAYTAlVTMRMwEQYD
# VQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMTH01pY3Jvc29mdCBDb2RlIFNpZ25p
# bmcgUENBIDIwMTEwHhcNMjMxMTE2MTkwOTAwWhcNMjQxMTE0MTkwOTAwWjB0MQsw
# CQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9u
# ZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMR4wHAYDVQQDExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24wggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIB
# AQDOS8s1ra6f0YGtg0OhEaQa/t3Q+q1MEHhWJhqQVuO5amYXQpy8MDPNoJYk+FWA
# hePP5LxwcSge5aen+f5Q6WNPd6EDxGzotvVpNi5ve0H97S3F7C/axDfKxyNh21MG
# 0W8Sb0vxi/vorcLHOL9i+t2D6yvvDzLlEefUCbQV/zGCBjXGlYJcUj6RAzXyeNAN
# xSpKXAGd7Fh+ocGHPPphcD9LQTOJgG7Y7aYztHqBLJiQQ4eAgZNU4ac6+8LnEGAL
# go1ydC5BJEuJQjYKbNTy959HrKSu7LO3Ws0w8jw6pYdC1IMpdTkk2puTgY2PDNzB
# tLM4evG7FYer3WX+8t1UMYNTAgMBAAGjggFzMIIBbzAfBgNVHSUEGDAWBgorBgEE
# AYI3TAgBBggrBgEFBQcDAzAdBgNVHQ4EFgQURxxxNPIEPGSO8kqz+bgCAQWGXsEw
# RQYDVR0RBD4wPKQ6MDgxHjAcBgNVBAsTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEW
# MBQGA1UEBRMNMjMwMDEyKzUwMTgyNjAfBgNVHSMEGDAWgBRIbmTlUAXTgqoXNzci
# tW2oynUClTBUBgNVHR8ETTBLMEmgR6BFhkNodHRwOi8vd3d3Lm1pY3Jvc29mdC5j
# b20vcGtpb3BzL2NybC9NaWNDb2RTaWdQQ0EyMDExXzIwMTEtMDctMDguY3JsMGEG
# CCsGAQUFBwEBBFUwUzBRBggrBgEFBQcwAoZFaHR0cDovL3d3dy5taWNyb3NvZnQu
# Y29tL3BraW9wcy9jZXJ0cy9NaWNDb2RTaWdQQ0EyMDExXzIwMTEtMDctMDguY3J0
# MAwGA1UdEwEB/wQCMAAwDQYJKoZIhvcNAQELBQADggIBAISxFt/zR2frTFPB45Yd
# mhZpB2nNJoOoi+qlgcTlnO4QwlYN1w/vYwbDy/oFJolD5r6FMJd0RGcgEM8q9TgQ
# 2OC7gQEmhweVJ7yuKJlQBH7P7Pg5RiqgV3cSonJ+OM4kFHbP3gPLiyzssSQdRuPY
# 1mIWoGg9i7Y4ZC8ST7WhpSyc0pns2XsUe1XsIjaUcGu7zd7gg97eCUiLRdVklPmp
# XobH9CEAWakRUGNICYN2AgjhRTC4j3KJfqMkU04R6Toyh4/Toswm1uoDcGr5laYn
# TfcX3u5WnJqJLhuPe8Uj9kGAOcyo0O1mNwDa+LhFEzB6CB32+wfJMumfr6degvLT
# e8x55urQLeTjimBQgS49BSUkhFN7ois3cZyNpnrMca5AZaC7pLI72vuqSsSlLalG
# OcZmPHZGYJqZ0BacN274OZ80Q8B11iNokns9Od348bMb5Z4fihxaBWebl8kWEi2O
# PvQImOAeq3nt7UWJBzJYLAGEpfasaA3ZQgIcEXdD+uwo6ymMzDY6UamFOfYqYWXk
# ntxDGu7ngD2ugKUuccYKJJRiiz+LAUcj90BVcSHRLQop9N8zoALr/1sJuwPrVAtx
# HNEgSW+AKBqIxYWM4Ev32l6agSUAezLMbq5f3d8x9qzT031jMDT+sUAoCw0M5wVt
# CUQcqINPuYjbS1WgJyZIiEkBMIIHejCCBWKgAwIBAgIKYQ6Q0gAAAAAAAzANBgkq
# hkiG9w0BAQsFADCBiDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24x
# EDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlv
# bjEyMDAGA1UEAxMpTWljcm9zb2Z0IFJvb3QgQ2VydGlmaWNhdGUgQXV0aG9yaXR5
# IDIwMTEwHhcNMTEwNzA4MjA1OTA5WhcNMjYwNzA4MjEwOTA5WjB+MQswCQYDVQQG
# EwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwG
# A1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSgwJgYDVQQDEx9NaWNyb3NvZnQg
# Q29kZSBTaWduaW5nIFBDQSAyMDExMIICIjANBgkqhkiG9w0BAQEFAAOCAg8AMIIC
# CgKCAgEAq/D6chAcLq3YbqqCEE00uvK2WCGfQhsqa+laUKq4BjgaBEm6f8MMHt03
# a8YS2AvwOMKZBrDIOdUBFDFC04kNeWSHfpRgJGyvnkmc6Whe0t+bU7IKLMOv2akr
# rnoJr9eWWcpgGgXpZnboMlImEi/nqwhQz7NEt13YxC4Ddato88tt8zpcoRb0Rrrg
# OGSsbmQ1eKagYw8t00CT+OPeBw3VXHmlSSnnDb6gE3e+lD3v++MrWhAfTVYoonpy
# 4BI6t0le2O3tQ5GD2Xuye4Yb2T6xjF3oiU+EGvKhL1nkkDstrjNYxbc+/jLTswM9
# sbKvkjh+0p2ALPVOVpEhNSXDOW5kf1O6nA+tGSOEy/S6A4aN91/w0FK/jJSHvMAh
# dCVfGCi2zCcoOCWYOUo2z3yxkq4cI6epZuxhH2rhKEmdX4jiJV3TIUs+UsS1Vz8k
# A/DRelsv1SPjcF0PUUZ3s/gA4bysAoJf28AVs70b1FVL5zmhD+kjSbwYuER8ReTB
# w3J64HLnJN+/RpnF78IcV9uDjexNSTCnq47f7Fufr/zdsGbiwZeBe+3W7UvnSSmn
# Eyimp31ngOaKYnhfsi+E11ecXL93KCjx7W3DKI8sj0A3T8HhhUSJxAlMxdSlQy90
# lfdu+HggWCwTXWCVmj5PM4TasIgX3p5O9JawvEagbJjS4NaIjAsCAwEAAaOCAe0w
# ggHpMBAGCSsGAQQBgjcVAQQDAgEAMB0GA1UdDgQWBBRIbmTlUAXTgqoXNzcitW2o
# ynUClTAZBgkrBgEEAYI3FAIEDB4KAFMAdQBiAEMAQTALBgNVHQ8EBAMCAYYwDwYD
# VR0TAQH/BAUwAwEB/zAfBgNVHSMEGDAWgBRyLToCMZBDuRQFTuHqp8cx0SOJNDBa
# BgNVHR8EUzBRME+gTaBLhklodHRwOi8vY3JsLm1pY3Jvc29mdC5jb20vcGtpL2Ny
# bC9wcm9kdWN0cy9NaWNSb29DZXJBdXQyMDExXzIwMTFfMDNfMjIuY3JsMF4GCCsG
# AQUFBwEBBFIwUDBOBggrBgEFBQcwAoZCaHR0cDovL3d3dy5taWNyb3NvZnQuY29t
# L3BraS9jZXJ0cy9NaWNSb29DZXJBdXQyMDExXzIwMTFfMDNfMjIuY3J0MIGfBgNV
# HSAEgZcwgZQwgZEGCSsGAQQBgjcuAzCBgzA/BggrBgEFBQcCARYzaHR0cDovL3d3
# dy5taWNyb3NvZnQuY29tL3BraW9wcy9kb2NzL3ByaW1hcnljcHMuaHRtMEAGCCsG
# AQUFBwICMDQeMiAdAEwAZQBnAGEAbABfAHAAbwBsAGkAYwB5AF8AcwB0AGEAdABl
# AG0AZQBuAHQALiAdMA0GCSqGSIb3DQEBCwUAA4ICAQBn8oalmOBUeRou09h0ZyKb
# C5YR4WOSmUKWfdJ5DJDBZV8uLD74w3LRbYP+vj/oCso7v0epo/Np22O/IjWll11l
# hJB9i0ZQVdgMknzSGksc8zxCi1LQsP1r4z4HLimb5j0bpdS1HXeUOeLpZMlEPXh6
# I/MTfaaQdION9MsmAkYqwooQu6SpBQyb7Wj6aC6VoCo/KmtYSWMfCWluWpiW5IP0
# wI/zRive/DvQvTXvbiWu5a8n7dDd8w6vmSiXmE0OPQvyCInWH8MyGOLwxS3OW560
# STkKxgrCxq2u5bLZ2xWIUUVYODJxJxp/sfQn+N4sOiBpmLJZiWhub6e3dMNABQam
# ASooPoI/E01mC8CzTfXhj38cbxV9Rad25UAqZaPDXVJihsMdYzaXht/a8/jyFqGa
# J+HNpZfQ7l1jQeNbB5yHPgZ3BtEGsXUfFL5hYbXw3MYbBL7fQccOKO7eZS/sl/ah
# XJbYANahRr1Z85elCUtIEJmAH9AAKcWxm6U/RXceNcbSoqKfenoi+kiVH6v7RyOA
# 9Z74v2u3S5fi63V4GuzqN5l5GEv/1rMjaHXmr/r8i+sLgOppO6/8MO0ETI7f33Vt
# Y5E90Z1WTk+/gFcioXgRMiF670EKsT/7qMykXcGhiJtXcVZOSEXAQsmbdlsKgEhr
# /Xmfwb1tbWrJUnMTDXpQzTGCGggwghoEAgEBMIGVMH4xCzAJBgNVBAYTAlVTMRMw
# EQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVN
# aWNyb3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMTH01pY3Jvc29mdCBDb2RlIFNp
# Z25pbmcgUENBIDIwMTECEzMAAAOvMEAOTKNNBUEAAAAAA68wDQYJYIZIAWUDBAIB
# BQCgga4wGQYJKoZIhvcNAQkDMQwGCisGAQQBgjcCAQQwHAYKKwYBBAGCNwIBCzEO
# MAwGCisGAQQBgjcCARUwLwYJKoZIhvcNAQkEMSIEIBhht7V621qoIOy6kjLsqgsx
# VueH01O+YTzDlnX/AA8ZMEIGCisGAQQBgjcCAQwxNDAyoBSAEgBNAGkAYwByAG8A
# cwBvAGYAdKEagBhodHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20wDQYJKoZIhvcNAQEB
# BQAEggEAQtcItyoBFS4Kk25+zZlfPQ2u2WmFzRhl4nfZmsfO4De0gRydUNllsdZr
# ORQbNA+9BmCE2cyEQ6b+/1uc4Gb7WF0uUm2/gild8qJfRnbtoNIwIkS5dyIiaz6R
# eChBqLa/BOV8PvfkB/biwJgwgyNKeE46qvSnTYhsPK+TApQmJmOPLbU8px1N4UfN
# 2W59/WCXx5v8jFUu+csShmby4u7wFkSp6amYbTVIAOKFi8pe8ZDtQPpgo5RrvOdJ
# ayJI8YO7Of1vQ4IedPS0SbRwFnB0NyYN2LYevvsimJ37atAtxWts+misvAC0BywX
# 9x+p37h7uBNBIyQtyq8tNuLcnEvY56GCF5IwgheOBgorBgEEAYI3AwMBMYIXfjCC
# F3oGCSqGSIb3DQEHAqCCF2swghdnAgEDMQ8wDQYJYIZIAWUDBAIBBQAwggFQBgsq
# hkiG9w0BCRABBKCCAT8EggE7MIIBNwIBAQYKKwYBBAGEWQoDATAxMA0GCWCGSAFl
# AwQCAQUABCBApegHGBjtfAHKFt/ossEZOx1ORkq8rjbo8CncIyqNoQIGZaAcJ/l7
# GBEyMDI0MDEyNTAwNDE0Ny4xWjAEgAIB9KCB0aSBzjCByzELMAkGA1UEBhMCVVMx
# EzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoT
# FU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjElMCMGA1UECxMcTWljcm9zb2Z0IEFtZXJp
# Y2EgT3BlcmF0aW9uczEnMCUGA1UECxMeblNoaWVsZCBUU1MgRVNOOjk2MDAtMDVF
# MC1EOTQ3MSUwIwYDVQQDExxNaWNyb3NvZnQgVGltZS1TdGFtcCBTZXJ2aWNloIIR
# 6jCCByAwggUIoAMCAQICEzMAAAHY/EszpR3YhRUAAQAAAdgwDQYJKoZIhvcNAQEL
# BQAwfDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcT
# B1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEmMCQGA1UE
# AxMdTWljcm9zb2Z0IFRpbWUtU3RhbXAgUENBIDIwMTAwHhcNMjMwNTI1MTkxMjQw
# WhcNMjQwMjAxMTkxMjQwWjCByzELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hp
# bmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jw
# b3JhdGlvbjElMCMGA1UECxMcTWljcm9zb2Z0IEFtZXJpY2EgT3BlcmF0aW9uczEn
# MCUGA1UECxMeblNoaWVsZCBUU1MgRVNOOjk2MDAtMDVFMC1EOTQ3MSUwIwYDVQQD
# ExxNaWNyb3NvZnQgVGltZS1TdGFtcCBTZXJ2aWNlMIICIjANBgkqhkiG9w0BAQEF
# AAOCAg8AMIICCgKCAgEAzXjrKdH14AM+xlBdDfv9BB3EBa4usJYk25kDZhZvA4tA
# nkPJ+G3drXebW7c07BJO3WNv55lmPZKhL2r23WEWzXPhLL/DX7+jDCJh/bQq+Ssb
# NueDENI5qUbnK5t7h1uNtQn72tITUBCjdTUtK2ndVP2Tpnvlf0HknViqHwk4cX/3
# 7E3keNVm6lDQCTf5pd7Gzh/Gi4V8kxxu7Fbf1lEi6U9Hy5TV2BkV82rydalDnj88
# o/OoYiss0CS04yq+xqUxhckoiHDFv58iujSu0Y38taHy3Ub77RyHSb6Zj0s3twh/
# z2BVNtU6oSIWdfgEu0ZQ6NfDEgxjx6UwlsKO5YLWNaWOkbzyILhd623bb4aMo5+Z
# j27OaYIxjvN6HQTT+yJSgI+AWx1F3h4rdw2toOwOI4nCqyzI6OrBnnrSaHiqKI+Y
# jU12w8CyjPR5VHV2Us+tn7QmVbivRQYJADvTETdqagZ6bQRn5ZZvttRS5OhN71Vz
# BhweXjoBXwMvOF5SInsnEAKyA7BJvdihyBThjoGZVsXuvZXl7zB42CZaaNlVTLS8
# Fy3d7Y0v9e96LhjEWoiyJy5uKCIKg7Y1CKr8GEFId0TesMHRe+Zzpq6a/MEcNZ/w
# SlkOZoUMWjAaqr5G7rtbC3kjD79jzGSHXVz24jrwMWnaj5AXDD1AZq8kmKC08cMC
# AwEAAaOCAUkwggFFMB0GA1UdDgQWBBT2049MfD2QS2J9DGQSOpxoeaiJVjAfBgNV
# HSMEGDAWgBSfpxVdAF5iXYP05dJlpxtTNRnpcjBfBgNVHR8EWDBWMFSgUqBQhk5o
# dHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20vcGtpb3BzL2NybC9NaWNyb3NvZnQlMjBU
# aW1lLVN0YW1wJTIwUENBJTIwMjAxMCgxKS5jcmwwbAYIKwYBBQUHAQEEYDBeMFwG
# CCsGAQUFBzAChlBodHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20vcGtpb3BzL2NlcnRz
# L01pY3Jvc29mdCUyMFRpbWUtU3RhbXAlMjBQQ0ElMjAyMDEwKDEpLmNydDAMBgNV
# HRMBAf8EAjAAMBYGA1UdJQEB/wQMMAoGCCsGAQUFBwMIMA4GA1UdDwEB/wQEAwIH
# gDANBgkqhkiG9w0BAQsFAAOCAgEArpwOmkj+PKCdVQ/kjBdf+0hYkxg+s8iwtybv
# R7S46mGKtRSVlMddCOV6lNGpXF01BVKFCFD0r33l/3V9DIKH1BvnDl3aJGhx0paO
# j2SA151ApaZEYsfcQjd+8hQaXMBi8xGZQyiW9oA6vxQRgvLJ05QUhDgY1dHhPCAl
# VJDicyALbRMWnkFieUnq1K+t56ul+z5kL5NTixZdxSaFuPucyqq4mPzyhrLDmgOW
# YwWRMlPqO/j94nC/8GdBt8ppU/hGuIfX96uWlXRlQXbIWGv0noRpp1LxjAPI+Qrd
# uIp8fm1TrhfxP9i4yKfphGq8uZjk6wDVSi8ptpFt3kMRfyPXI/O8Z3YmB+eV361j
# JPW7EU6MTqUW/RKWwgeXEsijb8UPA9NKndk53VRCRaYMgR0CUv1xCuaaHiWeaoJg
# hQI+FVDwf3T1x3U5tUFySN3Duw0cj1GQGDMENyoT5TNoT9jnwSSK/1bA7Id7Myy9
# mSbnq47IYcWBlW6DLnfWjaEY5c9THJ+IhKLWuLWptuBcQ8h66hZuhFELv6Q2BA6r
# rr0BRm+YJSHJOKyqgZ0Za0aIkY9KnYTt56KLVYP9Uj9M0ywtUa8Y7kxFXtzyqxE2
# 7b3Dg6Bofddl67X+MGzMKa2vI2LM8696X9PdOc8y/G/J/JLjAQoQWHxXbPdeik43
# OExjVPUwggdxMIIFWaADAgECAhMzAAAAFcXna54Cm0mZAAAAAAAVMA0GCSqGSIb3
# DQEBCwUAMIGIMQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4G
# A1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMTIw
# MAYDVQQDEylNaWNyb3NvZnQgUm9vdCBDZXJ0aWZpY2F0ZSBBdXRob3JpdHkgMjAx
# MDAeFw0yMTA5MzAxODIyMjVaFw0zMDA5MzAxODMyMjVaMHwxCzAJBgNVBAYTAlVT
# MRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQK
# ExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xJjAkBgNVBAMTHU1pY3Jvc29mdCBUaW1l
# LVN0YW1wIFBDQSAyMDEwMIICIjANBgkqhkiG9w0BAQEFAAOCAg8AMIICCgKCAgEA
# 5OGmTOe0ciELeaLL1yR5vQ7VgtP97pwHB9KpbE51yMo1V/YBf2xK4OK9uT4XYDP/
# XE/HZveVU3Fa4n5KWv64NmeFRiMMtY0Tz3cywBAY6GB9alKDRLemjkZrBxTzxXb1
# hlDcwUTIcVxRMTegCjhuje3XD9gmU3w5YQJ6xKr9cmmvHaus9ja+NSZk2pg7uhp7
# M62AW36MEBydUv626GIl3GoPz130/o5Tz9bshVZN7928jaTjkY+yOSxRnOlwaQ3K
# Ni1wjjHINSi947SHJMPgyY9+tVSP3PoFVZhtaDuaRr3tpK56KTesy+uDRedGbsoy
# 1cCGMFxPLOJiss254o2I5JasAUq7vnGpF1tnYN74kpEeHT39IM9zfUGaRnXNxF80
# 3RKJ1v2lIH1+/NmeRd+2ci/bfV+AutuqfjbsNkz2K26oElHovwUDo9Fzpk03dJQc
# NIIP8BDyt0cY7afomXw/TNuvXsLz1dhzPUNOwTM5TI4CvEJoLhDqhFFG4tG9ahha
# YQFzymeiXtcodgLiMxhy16cg8ML6EgrXY28MyTZki1ugpoMhXV8wdJGUlNi5UPkL
# iWHzNgY1GIRH29wb0f2y1BzFa/ZcUlFdEtsluq9QBXpsxREdcu+N+VLEhReTwDwV
# 2xo3xwgVGD94q0W29R6HXtqPnhZyacaue7e3PmriLq0CAwEAAaOCAd0wggHZMBIG
# CSsGAQQBgjcVAQQFAgMBAAEwIwYJKwYBBAGCNxUCBBYEFCqnUv5kxJq+gpE8RjUp
# zxD/LwTuMB0GA1UdDgQWBBSfpxVdAF5iXYP05dJlpxtTNRnpcjBcBgNVHSAEVTBT
# MFEGDCsGAQQBgjdMg30BATBBMD8GCCsGAQUFBwIBFjNodHRwOi8vd3d3Lm1pY3Jv
# c29mdC5jb20vcGtpb3BzL0RvY3MvUmVwb3NpdG9yeS5odG0wEwYDVR0lBAwwCgYI
# KwYBBQUHAwgwGQYJKwYBBAGCNxQCBAweCgBTAHUAYgBDAEEwCwYDVR0PBAQDAgGG
# MA8GA1UdEwEB/wQFMAMBAf8wHwYDVR0jBBgwFoAU1fZWy4/oolxiaNE9lJBb186a
# GMQwVgYDVR0fBE8wTTBLoEmgR4ZFaHR0cDovL2NybC5taWNyb3NvZnQuY29tL3Br
# aS9jcmwvcHJvZHVjdHMvTWljUm9vQ2VyQXV0XzIwMTAtMDYtMjMuY3JsMFoGCCsG
# AQUFBwEBBE4wTDBKBggrBgEFBQcwAoY+aHR0cDovL3d3dy5taWNyb3NvZnQuY29t
# L3BraS9jZXJ0cy9NaWNSb29DZXJBdXRfMjAxMC0wNi0yMy5jcnQwDQYJKoZIhvcN
# AQELBQADggIBAJ1VffwqreEsH2cBMSRb4Z5yS/ypb+pcFLY+TkdkeLEGk5c9MTO1
# OdfCcTY/2mRsfNB1OW27DzHkwo/7bNGhlBgi7ulmZzpTTd2YurYeeNg2LpypglYA
# A7AFvonoaeC6Ce5732pvvinLbtg/SHUB2RjebYIM9W0jVOR4U3UkV7ndn/OOPcbz
# aN9l9qRWqveVtihVJ9AkvUCgvxm2EhIRXT0n4ECWOKz3+SmJw7wXsFSFQrP8DJ6L
# GYnn8AtqgcKBGUIZUnWKNsIdw2FzLixre24/LAl4FOmRsqlb30mjdAy87JGA0j3m
# Sj5mO0+7hvoyGtmW9I/2kQH2zsZ0/fZMcm8Qq3UwxTSwethQ/gpY3UA8x1RtnWN0
# SCyxTkctwRQEcb9k+SS+c23Kjgm9swFXSVRk2XPXfx5bRAGOWhmRaw2fpCjcZxko
# JLo4S5pu+yFUa2pFEUep8beuyOiJXk+d0tBMdrVXVAmxaQFEfnyhYWxz/gq77EFm
# PWn9y8FBSX5+k77L+DvktxW/tM4+pTFRhLy/AsGConsXHRWJjXD+57XQKBqJC482
# 2rpM+Zv/Cuk0+CQ1ZyvgDbjmjJnW4SLq8CdCPSWU5nR0W2rRnj7tfqAxM328y+l7
# vzhwRNGQ8cirOoo6CGJ/2XBjU02N7oJtpQUQwXEGahC0HVUzWLOhcGbyoYIDTTCC
# AjUCAQEwgfmhgdGkgc4wgcsxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5n
# dG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9y
# YXRpb24xJTAjBgNVBAsTHE1pY3Jvc29mdCBBbWVyaWNhIE9wZXJhdGlvbnMxJzAl
# BgNVBAsTHm5TaGllbGQgVFNTIEVTTjo5NjAwLTA1RTAtRDk0NzElMCMGA1UEAxMc
# TWljcm9zb2Z0IFRpbWUtU3RhbXAgU2VydmljZaIjCgEBMAcGBSsOAwIaAxUASKfv
# sVCfn/OVa5283ZETEqQZry+ggYMwgYCkfjB8MQswCQYDVQQGEwJVUzETMBEGA1UE
# CBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9z
# b2Z0IENvcnBvcmF0aW9uMSYwJAYDVQQDEx1NaWNyb3NvZnQgVGltZS1TdGFtcCBQ
# Q0EgMjAxMDANBgkqhkiG9w0BAQsFAAIFAOlbvdcwIhgPMjAyNDAxMjQxNjQ4MjNa
# GA8yMDI0MDEyNTE2NDgyM1owdDA6BgorBgEEAYRZCgQBMSwwKjAKAgUA6Vu91wIB
# ADAHAgEAAgI03zAHAgEAAgIS4zAKAgUA6V0PVwIBADA2BgorBgEEAYRZCgQCMSgw
# JjAMBgorBgEEAYRZCgMCoAowCAIBAAIDB6EgoQowCAIBAAIDAYagMA0GCSqGSIb3
# DQEBCwUAA4IBAQCDDKJCACK4+kNG98iP8jS2/yBC2enWI7LU7+N2GSR1D8ezqDC/
# iK9Y6+z9AOFdS2vVDmd+kN7gq1UwZK8v7TnhbiVyuF8ps3j8vrzlGOmdFilzyjGg
# RpT5NZfz4QvDnuVUXyXrW9zFHIFAOQmO39s+tcGHn1pRMFeepptqrmREka8RfulZ
# EegKWd7VdvywADOlC8KKhK/9i4CGxYAs2QXc45PDEQKM+KIoXCZY/qfuPRvcKxKQ
# g35jzK0ZYMAiWITclSG+QTW095LpR8tjgq15Ux59XhhGxzi63438BQepxu2twwsf
# fYx9L8nNmwnCUsbAEOAptnbGUUuec63G72jMMYIEDTCCBAkCAQEwgZMwfDELMAkG
# A1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQx
# HjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEmMCQGA1UEAxMdTWljcm9z
# b2Z0IFRpbWUtU3RhbXAgUENBIDIwMTACEzMAAAHY/EszpR3YhRUAAQAAAdgwDQYJ
# YIZIAWUDBAIBBQCgggFKMBoGCSqGSIb3DQEJAzENBgsqhkiG9w0BCRABBDAvBgkq
# hkiG9w0BCQQxIgQgALV12Rp/e9oSbWHudB2nQjCaaaOHd6mQXVSe5v18QfAwgfoG
# CyqGSIb3DQEJEAIvMYHqMIHnMIHkMIG9BCA64yF//AmTd0UwATDbebu9zIt6N35r
# 6to/EopPtrO+VDCBmDCBgKR+MHwxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNo
# aW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29y
# cG9yYXRpb24xJjAkBgNVBAMTHU1pY3Jvc29mdCBUaW1lLVN0YW1wIFBDQSAyMDEw
# AhMzAAAB2PxLM6Ud2IUVAAEAAAHYMCIEIOEQwv2SePe0e99uw71QWBXRL/V6NuSq
# B1TErDm1PM7VMA0GCSqGSIb3DQEBCwUABIICAA7UczbKs+Vz7HFSdgxKxWnkKeSV
# 2EJ5YwovK8rZTOSm18lQv9PfzBQV1rVIadl8++qRIXh2NscdT5hzQdnCQLoWW21L
# 6UUpgIzlZ++yL2lDOhEG7j3XbqsRQZnbZSndU4FouIrEqksh0qtFYbDyB/hVzrcU
# LuTNjjy1YddyaLXUuYT0LU2S88zOvbmUgqJbf+i2YdLMqUDUIX5/q8GzeEEPi2kr
# dcPlI4fDHEtaCkysHNayGCdszATKmtBWPJJWkuW1qY9IBmeqdaKAi9UUh5DRTsRJ
# tctW3mruNZHnJkIlpgcqN2v4IDJmmzhnOqdIEw2c78JSf6OQQZYv0P3Jl71gBOCb
# oE/1nVnag+2Dfe1LIuTaJFhuxKnFu1VIhiCka/O/D6pFDCryaMTqVbbBU+A08ASD
# TAsjRyVFogt23wLOIExwIuz9Q2XP1vWSWA7u4OThaqdRJ+ZGztYzup9mvZb/gVRA
# PonFbR78HdrPXWWV93+VDRzhPZ2bvCvf8kG6GJ7a9TOHh8udBS+67NMOi54W2wOD
# 43DB8gUcJXyjCtR8d3MdmJJ7uHptSM+7pK/l8IsyCBrYgGheGsGsxA3eFpy2xc9Z
# UmjGP54TN5/NMjhAOFYGkIt+XsnYSFy5R2z2kiosa8o0YfLM1erqK6REUWJX6HXK
# RSraPCK09E444U/v
# SIG # End signature block
