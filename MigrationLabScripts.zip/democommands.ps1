# scripts available from aka.ms/appmigrate

$scriptsDir = "C:\Users\gseth\source\repos\devShop\MigrationScripts"

Write-Host "GET READINESS RESULTS FOR ALL SITES" -ForegroundColor Magenta
$readinessJsonFile = &$scriptsDir\Get-SiteReadiness.ps1 -ReadinessResultsOutputPath ..\readinessResults.json -OverwriteReadinessResults
# optional -ServerName -ServerCred to point to remote IIS server

Write-Host "PACKAGE SITE(S)" -ForegroundColor Magenta
$p = &$scriptsDir\Get-SitePackage.ps1 -ReadinessResultsFilePath $readinessJsonFile -OutputDirectory ..\packs -SiteName "Default Web Site" -Force
# may omit SiteName to package all sites in the readiness file
# may use -MigrateSitesWithIssues to package sites with errors as well

# Azure PowerShell is required for migration steps, you will be prompted if you don't already have it 
Write-Host "MAKE MIGRATION SETTINGS FILE" -ForegroundColor Magenta
$migrationSettingsFile = &$scriptsDir\Generate-MigrationSettings.ps1 -SitePackageResultsPath $p -Region 'EastUS2'  -SubscriptionId '7e574780-0f87-42e8-af8c-5e8cb7d3540a' -ResourceGroup 'rg-spoke-AppModMig-prod-eastus2' -MigrationSettingsFilePath ..\MigrationSettings.json -Force

#Modify to change SKU and make azure site name valid and unique
$sModified = '..\MigrationSettings2.json'
$MigrationSettings = Get-Content $migrationSettingsFile | ConvertFrom-Json
$oneASP = @($MigrationSettings[0])
$oneASP[0].Tier = "Standard"
$oneASP[0].Sites | ForEach-Object {$_.AzureSiteName = "$($_.AzureSiteName.replace(' ', ''))$($oneASP[0].ResourceGroup)"}
ConvertTo-Json $oneASP.psobject.BaseObject -depth 5 | Out-File $sModified -Force

Write-Host "START MIGRATION" -ForegroundColor Magenta 
$migrationOutput = &$scriptsDir\Invoke-SiteMigration.ps1 -MigrationSettingsFilePath $sModified -MigrationResultsFilePath ..\MigrationResults.json -Force

Write-Host "MIGRATION COMPLETE - opening browser" -ForegroundColor Magenta 
#launch migrated site browse link
$migrationOutput
start $migrationOutput[2].SiteBrowseLink

#done

