<#
  .SYNOPSIS
  Migrates sites to Azure App Service on Azure Cloud

  .DESCRIPTION
  Deploys, configures, and migrates sites
  to Azure App Service.

  .PARAMETER MigrationSettingsFilePath
  Specifies the path to the migration settings JSON file.
  
  .PARAMETER MigrationResultsFilePath
  Specifies a custom path for the summary file of the migration results
  
  .PARAMETER Force
  Overwrites pre-existing migration results output file
  
  .OUTPUTS
  Returns an object containing the summary migration results for all sites and related Azure resources created during migration

  .EXAMPLE
  C:\PS> .\Invoke-SiteMigration -MigrationSettingsFilePath "TemplateMigrationSettings.json"

  .EXAMPLE
  C:\PS> $MigrationOutput = .\Invoke-SiteMigration -MigrationSettingsFilePath "TemplateMigrationSettings.json"
#>

#Requires -Version 5.1
[CmdletBinding()]
param(
    [Parameter(Mandatory)]
    [string]$MigrationSettingsFilePath,
    
    [Parameter()]
    [string]$MigrationResultsFilePath,
    
    [Parameter()]
    [switch]$Force
)
Import-Module (Join-Path $PSScriptRoot "MigrationHelperFunctions.psm1")

$ScriptConfig = Get-ScriptConfig
$ScriptsVersion = $ScriptConfig.ScriptsVersion
$ResourcesCreated = @()
Add-Type -Assembly "System.IO.Compression.FileSystem" #Used to read files in .zip

Send-TelemetryEventIfEnabled -TelemetryTitle "Invoke-SiteMigration.ps1" -EventName "Started script" -EventType "action" -ErrorAction SilentlyContinue

if  (!$MigrationResultsFilePath) {
    $MigrationResultsFilePath = $ScriptConfig.DefaultMigrationResultsFilePath
}
if ((Test-Path $MigrationResultsFilePath) -and !$Force) {
    Write-HostError -Message  "$MigrationResultsFilePath already exists. Use -Force to overwrite $MigrationResultsFilePath"
    exit 1
}  

#Begin migration steps through Azure PowerShell - Login
Initialize-LoginToAzure
Test-InternetConnectivity

#Multiple sites can be migrated sequentially using migration settings file
try {
    $MigrationSettings = Get-Content $MigrationSettingsFilePath -Raw | ConvertFrom-Json
}
catch {
    Write-HostError "Error reading migration settings file: $($_.Exception.Message)"
    $ExceptionData = Get-ExceptionData -Exception $_.Exception
    Send-TelemetryEventIfEnabled -TelemetryTitle "Invoke-SiteMigration.ps1" -EventName "Error reading migration settings file" -ExceptionData $ExceptionData -EventType "error" -ErrorAction SilentlyContinue
    exit 1
}

if ($MigrationSettings -eq "") {
    Write-HostError "Migration settings file '$MigrationSettingsFilePath' is empty"
    Write-HostError "Use Generate-MigrationSettings.ps1 to generate migration settings"
    $ExceptionData = Get-ExceptionData -Exception $_.Exception
    Send-TelemetryEventIfEnabled -TelemetryTitle "Invoke-SiteMigration.ps1" -EventName "Migration settings file is empty" -ExceptionData $ExceptionData -EventType "error" -ErrorAction SilentlyContinue
    exit 1
}

function Get-SiteMigrationResult {
    param(
        [Parameter()]
        [string]$IISSiteName,

        [Parameter()]
        $MigrationStatus
    )
    $SiteMigrationResult = New-Object PSObject
    if ($IISSiteName) {
        Add-Member -InputObject $SiteMigrationResult -MemberType NoteProperty -Name IISSiteName -Value $IISSiteName
    }
    if ($MigrationStatus) {
        Add-Member -InputObject $SiteMigrationResult -MemberType NoteProperty -Name MigrationStatus -Value $MigrationStatus
    }

    return $SiteMigrationResult;
}

function Get-ResourceCreationResult {
    param(
        [Parameter()]
        [string]$ResourceName,

        [Parameter()]
        [string]$ResourceType,

        [Parameter()]
        [bool]$Created,
        
        [Parameter()]
        [string]$Error,
        
        [Parameter()]
        [string]$IISSiteName,
        
        [Parameter()]
        [string]$ManagementLink,
        
        [Parameter()]
        [string]$SiteBrowseLink
    )
    $ResourceCreationResult = New-Object PSObject
    if ($ResourceName) {
        Add-Member -InputObject $ResourceCreationResult -MemberType NoteProperty -Name ResourceName -Value $ResourceName
    }
    if ($ResourceType) {
        Add-Member -InputObject $ResourceCreationResult -MemberType NoteProperty -Name ResourceType -Value $ResourceType
    }
    Add-Member -InputObject $ResourceCreationResult -MemberType NoteProperty -Name Created -Value $Created  
    if ($Error) {
        Add-Member -InputObject $ResourceCreationResult -MemberType NoteProperty -Name Error -Value $Error
    }
    if ($IISSiteName) {
        Add-Member -InputObject $ResourceCreationResult -MemberType NoteProperty -Name IISSiteName -Value $IISSiteName
    }
    if ($ManagementLink) {
        Add-Member -InputObject $ResourceCreationResult -MemberType NoteProperty -Name ManagementLink -Value $ManagementLink
    }
    if ($SiteBrowseLink) {
        Add-Member -InputObject $ResourceCreationResult -MemberType NoteProperty -Name SiteBrowseLink -Value $SiteBrowseLink
    }    

    return $ResourceCreationResult;
}

function Add-ResourceResultError {
    param(
        [Parameter(Mandatory)]
        [object]$ResourceCreationResult,

        [Parameter(Mandatory)]
        [string]$Error
    )
   
    if($ResourceCreationResult.PSObject.Properties.Name -contains "Error") {
        $newError = "$($ResourceCreationResult.Error); $Error"
        $ResourceCreationResult.Error = $newError
    } else {
        Add-Member -InputObject $ResourceCreationResult -MemberType NoteProperty -Name Error -Value $Error
    }
}

function Disable-BasicAuthentication {
    param(
        [Parameter(Mandatory)]
        [string]$SubscriptionId,

        [Parameter(Mandatory)]
        [string]$ResourceGroup,

        [Parameter(Mandatory)]
        [string]$AzureSiteName,

        [Parameter(Mandatory)]
        [string]$Location,

        [Parameter(Mandatory)]
        [string]$AtName # ftp or scm
    )
   
    $disableAuthParams = @{
        SubscriptionId = $SubscriptionId
        ResourceGroupName = $ResourceGroup
        Name = @($AzureSiteName, $AtName)
        ResourceProviderName = "Microsoft.Web"
        ResourceType = @("sites", "basicPublishingCredentialsPolicies")
        ApiVersion = "2022-03-01"
        Payload = "{ `"location`": `"$Location`", `"properties`": { `"allow`": false } }"
        Method = "PUT"
    }

    $result = Invoke-AzRestMethod @disableAuthParams
    if ($result.StatusCode -ne "200")
    {
        $ErrorMsg = "Error status code disabling basic auth ($AtName) : $($result.StatusCode)"
        Write-HostWarn $ErrorMsg
        Send-TelemetryEventIfEnabled -TelemetryTitle "Invoke-SiteMigration.ps1" -EventName "Error disabling basic auth" -EventMessage $ErrorMsg -EventType "warn" -ErrorAction SilentlyContinue -Subscription $SubscriptionId -ResourceGroup $ResourceGroup -AzureSite $AzureSiteName              
    }
}

function Invoke-SiteCreationAndDeployment() {
    param(
        [Parameter()]
        [string]$Region,
        
        [Parameter()]
        [string]$SubscriptionId,

        [Parameter()]
        [string]$ResourceGroup,

        [Parameter()]
        [string]$AppServicePlan,
        
        [Parameter()]
        [string]$AppServiceEnvironment,
        
        [Parameter()]
        [string]$IISSiteName,

        [Parameter()]
        [string]$SitePackagePath,
        
        [Parameter()]
        [string]$AzureSiteName
    )       
    
    $AzurePortalLink = "$($ScriptConfig.PortalEndpoint)/#resource/subscriptions/$SubscriptionId/resourceGroups/$ResourceGroup/providers/Microsoft.Web/sites/$AzureSiteName/appServices"
    $siteResource = Get-ResourceCreationResult -ResourceName $AzureSiteName -ResourceType "Site" -Created $False -IISSiteName $IISSiteName -ManagementLink $AzurePortalLink
    
    #Create and deploy site (new Web App) to Azure (if ASE was provided, create it in that ASE)
    try {
        $InASELog = "";
        if ($AppServiceEnvironment) {
            $ASEDetails = Get-AzResource -Name $AppServiceEnvironment -ResourceType Microsoft.Web/hostingEnvironments
            $InASELog = " in ASE $AppServiceEnvironment"
            $AspId = (Get-AzAppServicePlan -ResourceGroupName $ResourceGroup -Name $AppServicePlan).Id
            $NewAzureApp = New-AzWebApp -Name $AzureSiteName -ResourceGroupName $ResourceGroup -AppServicePlan $AspId -Location $ASEDetails.Location -AseName $AppServiceEnvironment -AseResourceGroupName $ASEDetails.ResourceGroupName  -ErrorAction Stop
        } else {
            $AspId = (Get-AzAppServicePlan -ResourceGroupName $ResourceGroup -Name $AppServicePlan).Id
            $NewAzureApp = New-AzWebApp -Name $AzureSiteName -ResourceGroupName $ResourceGroup -AppServicePlan $AspId -Location $Region -ErrorAction Stop
        }
                
        $siteResource.Created = $True 
    }
    catch {
        $ExceptionMsg = Get-AzExceptionMessage -Exception $_.Exception
        $ErrorMsg = "Error creating Web App$InASELog for site '$IISSiteName' : $ExceptionMsg"
        Write-HostError $ErrorMsg
        $ExceptionData = Get-ExceptionData -Exception $ExceptionMsg
        Send-TelemetryEventIfEnabled -TelemetryTitle "Invoke-SiteMigration.ps1" -EventName "Error creating web app" -EventMessage "Error creating web app" -ExceptionData $ExceptionData -EventType "error" -ErrorAction SilentlyContinue -Subscription $SubscriptionId -ResourceGroup $ResourceGroup -AzureSite $AzureSiteName              
        Add-ResourceResultError -ResourceCreationResult $siteResource -Error $ErrorMsg
        return $siteResource
    }

    Write-HostInfo "Created Web App $($NewAzureApp.Name)$InASELog for the site '$IISSiteName'"
    Send-TelemetryEventIfEnabled -TelemetryTitle "Invoke-SiteMigration.ps1" -EventName "Successfully created web app" -EventMessage "Successfully created web app" -EventType "info" -Subscription $SubscriptionId -ResourceGroup $ResourceGroup -AzureSite $AzureSiteName -ErrorAction SilentlyContinue
    
    # Explicitly disable basic authentication for the site
    try {
        Disable-BasicAuthentication -SubscriptionId $SubscriptionId -ResourceGroup $NewAzureApp.ResourceGroup -AzureSiteName $NewAzureApp.Name -Location $NewAzureApp.Location -AtName "ftp"
        Disable-BasicAuthentication -SubscriptionId $SubscriptionId -ResourceGroup $NewAzureApp.ResourceGroup -AzureSiteName $NewAzureApp.Name -Location $NewAzureApp.Location -AtName "scm"
    }
    catch {
        $ExceptionMsg = Get-AzExceptionMessage -Exception $_.Exception
        $ErrorMsg = "Error explicitly disabling basic auth for site '$AzureSiteName' : $ExceptionMsg"
        Write-HostError $ErrorMsg
        $ExceptionData = Get-ExceptionData -Exception $ExceptionMsg        
        Send-TelemetryEventIfEnabled -TelemetryTitle "Invoke-SiteMigration.ps1" -EventName "Error disabling basic auth" -EventMessage "Error disabling basic auth" -ExceptionData $ExceptionData -EventType "error" -ErrorAction SilentlyContinue -Subscription $SubscriptionId -ResourceGroup $ResourceGroup -AzureSite $AzureSiteName              
    }

    #Use the SiteConfig file to push site settings to Azure
    $SiteConfig = (Get-ZippedFileContents -ZipPath $SitePackagePath -NameOfFile "SiteConfig.json") | ConvertFrom-Json

    if (!$SiteConfig) {
        Write-HostError "Site configuration file (SiteConfig.json) was not found or was empty! Unable to configure site settings."      
        Add-ResourceResultError -ResourceCreationResult $siteResource -Error "Missing SiteConfig.json in package .zip, site settings may not be configured or content may not be in correct format."
    }
    else {
        Write-HostInfo "Configuring Azure settings for Azure site $($SetAzureSiteSettings.Name)"

        $SetAzureSiteSettings = Set-AzWebApp -ResourceGroupName $ResourceGroup -Name $AzureSiteName -Use32BitWorkerProcess $SiteConfig.Is32Bit -ManagedPipelineMode $SiteConfig.ManagedPipelineMode -NetFrameworkVersion $SiteConfig.NetFrameworkVersion -ErrorVariable SetSettingsError #-ErrorAction SilentlyContinue
        
        if($SetSettingsError) {
            $settingsErrorMsg = "Error setting App Service configuration settings: $($SetSettingsError.Exception)"
            Write-HostError $settingsErrorMsg
            Add-ResourceResultError -ResourceCreationResult $siteResource -Error $settingsErrorMsg
        }
        
        #Set the site's virtual applications
        Write-HostInfo "Configuring any virtual directories..."
        if ($SiteConfig.VirtualApplications) {
            $SiteConfigResource = Get-AzResource -ResourceType "Microsoft.Web/sites" -ResourceGroupName $ResourceGroup -ResourceName $AzureSiteName

            $SiteConfigResource.properties.siteConfig.virtualApplications = $SiteConfig.VirtualApplications.clone()

            $SetVirtualDirectories = $SiteConfigResource | Set-AzResource -ErrorVariable ErrorConfiguringSite -Force
            if ($ErrorConfiguringSite) {
                Write-HostError $ErrorConfiguringSite.Exception
                Add-ResourceResultError -ResourceCreationResult $siteResource -Error $ErrorConfiguringSite.Exception                
            }
            else {
                Write-HostInfo "Virtual directories/applications have been configured on Azure for $($SetVirtualDirectories.Name)"
            }
        }
    }

    #Deploy/Publish the site and check for errors
    Write-HostInfo "Beginning zip deployment..."
    
    #Get site scm hostname
    try {       
        if($NewAzureApp.EnabledHostNames.Count -gt 0) {         
            $scmHostname = $NewAzureApp.EnabledHostNames -match ".scm."
            $SiteURI = $NewAzureApp.EnabledHostNames -notmatch ".scm."
        }
    } catch {       
        $hostnameErrorMsg = "$Error getting site scm endpoint hostname from EnabledHostnames information: ($_.Exception.Message)"
        Write-HostError $hostnameErrorMsg
        $ExceptionData = Get-ExceptionData -Exception $_.Exception
        Send-TelemetryEventIfEnabled -TelemetryTitle "Invoke-SiteMigration.ps1" -EventName "Error getting scm hostname from EnabledHostnames" -ExceptionData $ExceptionData -EventType "error" -ErrorAction SilentlyContinue -Subscription $SubscriptionId -ResourceGroup $ResourceGroup -AzureSite $AzureSiteName        
    }
    
    if(!$scmHostname) {
        #Did not find or set expected scm hostname from created site info
        $scmHostname = "$AzureSiteName.scm.azurewebsites.net"
        Write-HostWarn "Using default constructed site scm hostname ($scmHostname)"     
    }
    if(!$SiteURI) {
        #Did not find or set expected default hostname from created site info
        $SiteURI = "$AzureSiteName.azurewebsites.net"
        Write-HostWarn "Using default constructed site browse link ($SiteURI)"      
    }

    try {
        $token = (Get-AzAccessToken).Token
        $Headers = @{
            authorization = "Bearer $token"
        }
        $DeploymentURI = "https://$scmHostname/api/zip"

        [void](Invoke-RestMethod -Uri $DeploymentURI -Method 'PUT' -ContentType "multipart/form-data" -Headers $Headers -InFile $SitePackagePath -UserAgent "migrationps/v$ScriptsVersion")

        Write-HostInfo "Succesfully migrated site '$IISSiteName' to $SiteURI"
    }
    catch {
        $AdditionalNote = ""
        $DeploymentErrorEventMessage = ""
        if($_.CategoryInfo -and $_.CategoryInfo.TargetName -eq 'Get-AzAccessToken' -and $_.CategoryInfo.Reason -eq 'CommandNotFoundException') {
            $AdditionalNote = " Please try updating the Az.Account module to a later version, more information on updating Azure PowerShell: https://go.microsoft.com/fwlink/?linkid=2250167"
            $DeploymentErrorEventMessage = "Get-AzAccessToken CommandNotFoundException"
        }
        Write-HostError "Error deploying site zip $SitePackagePath for the site '$IISSiteName': $($_.Exception.Message)$AdditionalNote"
        
        $ExceptionData = Get-ExceptionData -Exception $_.Exception
        Send-TelemetryEventIfEnabled -TelemetryTitle "Invoke-SiteMigration.ps1" -EventName "Error deploying site" -EventMessage $DeploymentErrorEventMessage -ExceptionData $ExceptionData -EventType "error" -ErrorAction SilentlyContinue -Subscription $SubscriptionId -ResourceGroup $ResourceGroup -AzureSite $AzureSiteName
        Add-ResourceResultError -ResourceCreationResult $siteResource -Error "Error deploying site content: $($_.Exception.Message)$AdditionalNote"
        return $siteResource
    }
    Send-TelemetryEventIfEnabled -TelemetryTitle "Invoke-SiteMigration.ps1" -EventName "Successfully deployed site" -EventType "info" -Subscription $SubscriptionId -ResourceGroup $ResourceGroup -AzureSite $AzureSiteName -ErrorAction SilentlyContinue
    
    Add-Member -InputObject $siteResource -MemberType NoteProperty -Name SiteBrowseLink -Value "http://$SiteURI"    
    return $siteResource
}

function Test-AzureSiteNames() {
    $AzureSites = New-Object System.Collections.ArrayList
    $UnavailableSites = New-Object System.Collections.ArrayList
    foreach ($SettingsObject in $MigrationSettings) {
        $Sites = $SettingsObject.Sites; 
        $SubscriptionId = $SettingsObject.SubscriptionId; 
        foreach ($Site in $Sites) {
            $AzureSiteName = $Site.AzureSiteName
            if ($AzureSites -contains $AzureSiteName) {
                Write-HostError "All the sites in $MigrationSettingsFilePath should have a unique AzureSiteName"
                Write-HostError "AzureSiteName '$AzureSiteName' is used for more than one site in $MigrationSettingsFilePath"
                exit 1
            }
            [void]$AzureSites.Add($AzureSiteName)
        } 
    }

    foreach ($SiteName in $AzureSites) {
        $SiteAvailabilityResponse = AzureSiteNameAvailability -SiteName $SiteName -AzureSubscriptionId $SubscriptionId
        if (!$SiteAvailabilityResponse.nameAvailable) {
            Write-HostError "AzureSiteName '$SiteName' $($SiteAvailabilityResponse.reason). $($SiteAvailabilityResponse.message)"
            [void] $UnavailableSites.Add($SiteName)
        }
    }

    if ($UnavailableSites.Count -ne 0) {
        Write-HostError "Certain Azure site names in $MigrationSettingsFilePath are not available on Azure cloud"
        Write-HostError "Site names not available are: $($UnavailableSites -join ', ')"
        Send-TelemetryEventIfEnabled -TelemetryTitle "Invoke-SiteMigration.ps1" -EventName "Azure site name not available" -EventType "error" -ErrorAction SilentlyContinue
        exit 1
    }
}

function Test-SettingFailIfMissing() {
    param(
        [Parameter(Mandatory)]
        [string]$SettingToCheck,

        [Parameter(Mandatory)]
        [string]$ItemName,

        [Parameter(Mandatory)]
        [string]$AppServicePlan,

        [Parameter(Mandatory)]
        [string]$MigrationSettingsFilePath
    )
    if (!$SettingToCheck) {
        Write-HostError "$ItemName value missing for AppServicePlan '$AppServicePlan' in $MigrationSettingsFilePath"
        exit 1
    }        
}

function Write-AzureResourceResults() {
    param(
        [Parameter(Mandatory)]
        [object[]]$ResourceSummaryInfo,

        [Parameter(Mandatory)]
        [string]$MigrationResultsFilePath
    )
    if ($ResourceSummaryInfo) {
        Write-HostInfo "Resources created during migration"
        Write-HostInfo ($ResourceSummaryInfo | Format-Table -Property ResourceName,ResourceType,Created,Error | Out-String)  
        
        try {
            ConvertTo-Json $ResourceSummaryInfo -Depth 10 | Out-File (New-Item -Path $MigrationResultsFilePath -ItemType "file" -ErrorAction Stop -Force)
            Write-HostInfo "Migration resource creation results saved to $MigrationResultsFilePath"
        }
        catch {
            Write-HostError -Message "Error creating migration results file: $($_.Exception.Message)" 
            Send-TelemetryEventIfEnabled -TelemetryTitle "Generate-MigrationSettings.ps1" -EventName "Error in creating migration results file" -EventType "error" -ErrorAction SilentlyContinue    
        } 
    } else {
        Write-HostInfo "$MigrationResultsFilePath was not created as Azure resources were not created."
    }       
}


#validating all the settings in the migration settings file
try {
    foreach ($SettingsObject in $MigrationSettings) {
        $AppServicePlan = $SettingsObject.AppServicePlan
        $Region = $SettingsObject.Region
        $SubscriptionId = $SettingsObject.SubscriptionId
        $ResourceGroup = $SettingsObject.ResourceGroup
        $Tier = $SettingsObject.Tier
        $NumberOfWorkers = $SettingsObject.NumberOfWorkers
        $WorkerSize = $SettingsObject.WorkerSize
        $AppServiceEnvironment = $SettingsObject.AppServiceEnvironment

        $Sites = $SettingsObject.Sites;  

        if (!$AppServicePlan) {
            Write-HostError "AppServicePlan value not found for some sites in $MigrationSettingsFilePath"
            exit 1
        }
    
        if (!$Sites -or $Sites.count -lt 1) {
            Write-HostError "No sites present for AppServicePlan '$AppServicePlan' in $MigrationSettingsFilePath, all App Service Plans should contain at least one site"
            exit 1
        }
            
        Test-SettingFailIfMissing -SettingToCheck $SubscriptionId -ItemName "SubscriptionId" -AppServicePlan $AppServicePlan -MigrationSettingsFilePath $MigrationSettingsFilePath
        Test-SettingFailIfMissing -SettingToCheck $ResourceGroup -ItemName "ResourceGroup" -AppServicePlan $AppServicePlan -MigrationSettingsFilePath $MigrationSettingsFilePath   
    
        Test-AzureResources -SubscriptionId $SubscriptionId -Region $Region -AppServiceEnvironment $AppServiceEnvironment -ResourceGroup $ResourceGroup -SkipWarnOnRGNotExists
       
        if($AppServiceEnvironment) {
            if($Tier -and !$Tier.StartsWith("Isolated")) {
                Write-HostError "Isolated SKUs must be specified for App Service Plans on App Service Environments. Please update Tier value on AppServicePlan 'AppServicePlan' to the appropriate Isolated SKU ('Isolated'|'IsolatedV2')"
                exit 1
            }
        } else {
            if($Tier -and $Tier.StartsWith("Isolated")) {
                Write-HostError "Isolated SKUs may only be used for App Service Plans on App Service Environments. Please update Tier value on AppServicePlan 'AppServicePlan' to a non-Isolated SKU"
                exit 1
            }
        }                

        #validating asp 
        $ExistingAppServicePlan = Get-AzAppServicePlan -ResourceGroupName $ResourceGroup -Name $AppServicePlan -ErrorAction Stop
       
        if ($ExistingAppServicePlan) {
            Write-HostInfo "Found App Service Plan $AppServicePlan in Resource Group $ResourceGroup"                    
            
            if($AppServiceEnvironment -and (!$ExistingAppServicePlan.HostingEnvironmentProfile -or $ExistingAppServicePlan.HostingEnvironmentProfile.Name -ne $AppServiceEnvironment)) {
                $ASEMisMatchExplainClause = "which is not on an App Service Environment"
                if($ExistingAppServicePlan.HostingEnvironmentProfile -and $ExistingAppServicePlan.HostingEnvironmentProfile.Name -ne $AppServiceEnvironment) {
                    $ASEMisMatchExplainClause = "which is on App Service Environment '$($ExistingAppServicePlan.HostingEnvironmentProfile.Name)'"
                }
                Write-HostError "Specified App Service Environment setting ($AppServiceEnvironment) does not match pre-existing App Service Plan '$AppServicePlan' $ASEMisMatchExplainClause"
                exit 1
            }
            # warn if ASP settings were specified but don't match existing ASP properties
            if($Region) {
                Write-HostWarn "Specified Region setting ($Region) will be ignored for pre-existing App Service Plan '$AppServicePlan' (current location: $($ExistingAppServicePlan.Location))"
            }
            if($Tier -and $ExistingAppServicePlan.Sku.Tier -ne $Tier) {               
                Write-HostWarn "Specified Tier setting ($Tier) will be ignored for pre-existing App Service Plan '$AppServicePlan' (current Tier: $($ExistingAppServicePlan.Sku.Tier))"
            }
            if($NumberOfWorkers -and $ExistingAppServicePlan.Sku.Capacity) {
                Write-HostWarn "Specified NumberOfWorkers setting ($NumberOfWorkers) will be ignored for pre-existing App Service Plan '$AppServicePlan' (current capacity: $($ExistingAppServicePlan.Sku.Capacity))"
            }
            if($WorkerSize) {
                Write-HostWarn "Sepecified WorkerSize setting ($WorkerSize) will be ignored for pre-existing App Service Plan $AppServicePlan"
            }   
        } else {
            Write-HostInfo "App Service Plan $AppServicePlan not found in Resource Group $ResourceGroup, it will be created"  
            Test-SettingFailIfMissing -SettingToCheck $Region -ItemName "Region" -AppServicePlan $AppServicePlan -MigrationSettingsFilePath $MigrationSettingsFilePath
            Test-SettingFailIfMissing -SettingToCheck $Tier -ItemName "Tier" -AppServicePlan $AppServicePlan -MigrationSettingsFilePath $MigrationSettingsFilePath        
            Test-SettingFailIfMissing -SettingToCheck $NumberOfWorkers -ItemName "NumberOfWorkers" -AppServicePlan $AppServicePlan -MigrationSettingsFilePath $MigrationSettingsFilePath        
            Test-SettingFailIfMissing -SettingToCheck $WorkerSize -ItemName "WorkerSize" -AppServicePlan $AppServicePlan -MigrationSettingsFilePath $MigrationSettingsFilePath              
        }                    
        
        foreach ($Site in $Sites) {
            $IISSiteName = $Site.IISSiteName
            $SitePackagePath = $Site.SitePackagePath
            if (!$SitePackagePath) {
                Write-HostError "Path to site zip setting 'SitePackagePath' missing for the site '$IISSiteName' in $MigrationSettingsFilePath"
                exit 1
            }               
            # get full path to package files: if relative, should be relative to migration settings file
            if(-not ([System.IO.Path]::IsPathRooted($SitePackagePath))) {
                $migrationFileFullPath = $MigrationSettingsFilePath
                if(-not ([System.IO.Path]::IsPathRooted($migrationFileFullPath))) {
                    $migrationFileFullPath = Join-Path (Get-Location).Path $MigrationSettingsFilePath
                }
                $fullPkgPath = Join-Path (Split-Path -Path $migrationFileFullPath) $Site.SitePackagePath
                $SitePackagePath = $fullPkgPath
            }
            $AzureSiteName = $Site.AzureSiteName
    
            if (!$IISSiteName) {
                Write-HostError "IISSiteName value missing for site under AppServicePlan '$AppServicePlan' in $MigrationSettingsFilePath"
                exit 1
            }
    
            if (!$SitePackagePath -or !(Test-Path $SitePackagePath)) {
                Write-HostError "SitePackagePath value missing or zip not found for IISSiteName '$IISSiteName' under AppServicePlan '$AppServicePlan' in $MigrationSettingsFilePath"
                exit 1
            }
    
            if (!$AzureSiteName) {
                Write-HostError "AzureSiteName value missing for IISSiteName '$IISSiteName' under AppServicePlan '$AppServicePlan' in $MigrationSettingsFilePath"
                exit 1
            }
        }
    }
    #Testing if all the Azure site names in migration settings file are available
    Test-AzureSiteNames
} catch {
    Write-HostError "Error in validating settings in $MigrationSettingsFilePath : $($_.Exception.Message)"
    Write-HostError "Can't proceed to migration without validating settings, please test your internet connection and regenerate migration settings file and retry"
    Write-HostError "Migrations settings file can be generated by running Generate-MigrationSettings.ps1"
    exit 1
} 

# Only start creating resources after basic setting validation above completes successfully
foreach ($SettingsObject in $MigrationSettings) {
    $AppServicePlan = $SettingsObject.AppServicePlan
    $Region = $SettingsObject.Region
    $SubscriptionId = $SettingsObject.SubscriptionId
    $ResourceGroup = $SettingsObject.ResourceGroup
    $Tier = $SettingsObject.Tier
    $NumberOfWorkers = $SettingsObject.NumberOfWorkers
    $WorkerSize = $SettingsObject.WorkerSize
    $AppServiceEnvironment = $SettingsObject.AppServiceEnvironment

    $Sites = $SettingsObject.Sites;  

    Write-HostInfo "Creating App Service Plan '$AppServicePlan' resources"
    #Creates App service plan and other resources    
    try {
        #Set Azure account subscription
        $SetSubscription = Set-AzContext -SubscriptionId $SubscriptionId
    }
    catch {
        Write-HostError "Error setting subscription from Id: $($_.Exception.Message)"
        $ExceptionData = Get-ExceptionData -Exception $_.Exception
        Send-TelemetryEventIfEnabled -TelemetryTitle "Invoke-SiteMigration.ps1" -EventName "Error setting subscription" -ExceptionData $ExceptionData -EventType "error" -ErrorAction SilentlyContinue
        Write-AzureResourceResults -ResourceSummaryInfo $script:ResourcesCreated -MigrationResultsFilePath $MigrationResultsFilePath 
        exit 1
    }

    Write-HostInfo "Azure subscription has been set to $($SetSubscription.Subscription.Id) (Name: $($SetSubscription.Subscription.Name))"
    Send-TelemetryEventIfEnabled -TelemetryTitle "Invoke-SiteMigration.ps1" -EventName "Subscription was successfully set" -EventType "info" -Subscription $SubscriptionId -ErrorAction SilentlyContinue

    #Create Azure resource group if it doesn't already exist
    $GetResourceGroup = Get-AzResourceGroup -Name $ResourceGroup -ErrorVariable RscGrpNotFound -ErrorAction SilentlyContinue
    if ($RscGrpNotFound) {
        try {
            $NewResourceGroup = New-AzResourceGroup -Name $ResourceGroup -Location $Region -ErrorAction Stop
            $script:ResourcesCreated += Get-ResourceCreationResult -ResourceName $ResourceGroup -ResourceType "ResourceGroup" -Created $True
        }
        catch {
            Write-HostError "Error creating Resource Group: $($_.Exception.Message)"
            $ExceptionData = Get-ExceptionData -Exception $_.Exception
            Send-TelemetryEventIfEnabled -TelemetryTitle "Invoke-SiteMigration.ps1" -EventName "Resource Group creation failed" -EventMessage "Resource Group $ResourceGroup creation failed" -ExceptionData $ExceptionData -EventType "info" -Subscription $SubscriptionId -ResourceGroup $ResourceGroup -ErrorAction SilentlyContinue
            $script:ResourcesCreated += Get-ResourceCreationResult -ResourceName $ResourceGroup -ResourceType "ResourceGroup" -Created $False
            Write-AzureResourceResults -ResourceSummaryInfo $script:ResourcesCreated -MigrationResultsFilePath $MigrationResultsFilePath  
            exit 1
        }
        
        Write-HostInfo "Resource Group $($ResourceGroup) has been created in $($NewResourceGroup.Location)"
        Send-TelemetryEventIfEnabled -TelemetryTitle "Invoke-SiteMigration.ps1" -EventName "Resource Group created" -EventType "info" -Subscription $SubscriptionId -ResourceGroup $ResourceGroup -ErrorAction SilentlyContinue
    }
    else {
        Write-HostInfo "Resource Group $ResourceGroup found in $($GetResourceGroup.Location)"
        Send-TelemetryEventIfEnabled -TelemetryTitle "Invoke-SiteMigration.ps1" -EventName "Resource Group already existed" -EventType "info" -Subscription $SubscriptionId -ResourceGroup $ResourceGroup -ErrorAction SilentlyContinue
    }

    #Create Azure App Service Plan if it doesn't already exist
    $ExistingAppServicePlan = Get-AzAppServicePlan -ResourceGroupName $ResourceGroup -Name $AppServicePlan -ErrorAction Stop
        
    if ($ExistingAppServicePlan) {                       
        # don't need to create one
        Write-HostInfo "App Service Plan $($ExistingAppServicePlan.Name) found in resource group $($ExistingAppServicePlan.ResourceGroup)"
        Send-TelemetryEventIfEnabled -TelemetryTitle "Invoke-SiteMigration.ps1" -EventName "ASP pre-existing" -EventMessage "$($ExistingAppServicePlan.Name)" -EventType "info" -Subscription $SubscriptionId -ResourceGroup $ResourceGroup -ErrorAction SilentlyContinue 
        $Region = $ExistingAppServicePlan.Location
    }
    else {
        #ASP not found, creating new one in specifed region
        try {
            $InASELog = "";
            if ($AppServiceEnvironment) {      
                Send-TelemetryEventIfEnabled -TelemetryTitle "Invoke-SiteMigration.ps1" -EventName "ASE used" -EventMessage "$AppServiceEnvironment" -EventType "info" -ErrorAction SilentlyContinue      
                $InASELog = " in App Service Environment $AppServiceEnvironment"
                $ASEDetails = Get-AzResource -Name $AppServiceEnvironment -ResourceType Microsoft.Web/hostingEnvironments
                if($Region -and $AseDetails.Location -ne $Region) {
                    Write-HostWarn "Region '$Region' provided is different from App Service Environment '$AppServiceEnvironment' region $AseDetails.Location"
                    Write-HostWarn "Sites within '$AppServicePlan' will be migrated to  $AseDetails.Location"
                }           
                $ASEDetailsWithVer = Get-AzAppServiceEnvironment -Name $AppServiceEnvironment -ResourceGroupName $ASEDetails.ResourceGroupName
                if($ASEDetailsWithVer.Kind) {
                    if($ASEDetailsWithVer.Kind -eq "ASEV3" -and $Tier -ne "IsolatedV2") {
                        Write-HostWarn "ASE is v3 version which uses IsolatedV2 but Tier $Tier was specified - App Service Plan will be created using IsolatedV2 SKU"                    
                        $Tier = "IsolatedV2"
                    }
                    if($ASEDetailsWithVer.Kind -eq "ASEV2" -and $Tier -ne "Isolated") {
                        Write-HostWarn "ASE is v2 version which uses Isolated but Tier $Tier was specified - App Service Plan will be created using Isolated SKU"                    
                        $Tier = "Isolated"
                    }
                } else {
                    Write-HostWarn "Unable to get ASE version information, App Service Plan will be created using specified Tier of $Tier"                
                }
                Write-HostInfo "Creating App Service Plan $AppServicePlan in App Service Environment $AppServiceEnvironment ...."
                Write-HostInfo "This might take a while, especially if this is the first App service plan being created$InASELog"
                $NewAppServicePlan = New-AzAppServicePlan -Name $AppServicePlan -ResourceGroupName $ResourceGroup -Location $ASEDetails.Location -Tier $Tier -NumberofWorkers $NumberOfWorkers -WorkerSize $WorkerSize -AseName $AppServiceEnvironment -AseResourceGroupName $ASEDetails.ResourceGroupName -ErrorAction Stop 
            } else {
                Write-HostInfo "Creating App Service Plan $AppServicePlan ...."
                $NewAppServicePlan = New-AzAppServicePlan -ResourceGroupName $ResourceGroup -Name $AppServicePlan  -Location $Region -Tier $Tier -NumberofWorkers $NumberOfWorkers -WorkerSize $WorkerSize -ErrorAction Stop
            }
            $script:ResourcesCreated += Get-ResourceCreationResult -ResourceName $AppServicePlan -ResourceType "App Service Plan" -Created $True
        }
        catch {
            $ExceptionMsg = Get-AzExceptionMessage -Exception $_.Exception
            Write-HostError "Error creating $AppServicePlan$InASELog : $ExceptionMsg"
            $ExceptionData = Get-ExceptionData -Exception $ExceptionMsg  
            Send-TelemetryEventIfEnabled -TelemetryTitle "Invoke-SiteMigration.ps1" -EventName "Error creating ASP" -EventMessage "$AppServicePlan" -ExceptionData $ExceptionData -EventType "error" -ErrorAction SilentlyContinue -Subscription $SubscriptionId -ResourceGroup $ResourceGroup
            $script:ResourcesCreated += Get-ResourceCreationResult -ResourceName $AppServicePlan -ResourceType "App Service Plan" -Created $False -Error $ExceptionMsg
            Write-AzureResourceResults -ResourceSummaryInfo $script:ResourcesCreated -MigrationResultsFilePath $MigrationResultsFilePath 
            exit 1
        }
       
        Write-HostInfo "App Service Plan $($NewAppServicePlan.Name) has been created in resource group $($NewAppServicePlan.ResourceGroup)$InASELog"
        Send-TelemetryEventIfEnabled -TelemetryTitle "Invoke-SiteMigration.ps1" -EventName "ASP created" -EventMessage "$($NewAppServicePlan.Name)" -EventType "info" -Subscription $SubscriptionId -ResourceGroup $ResourceGroup -ErrorAction SilentlyContinue         
    }
	
    #Create sites within ASP
    foreach ($Site in $Sites) {
        $IISSiteName = $Site.IISSiteName
        $SitePackagePath = $Site.SitePackagePath
        # get full path to package files if relative to package results file
        if(-not ([System.IO.Path]::IsPathRooted($SitePackagePath))) {
            $fullPkgPath = Join-Path (Split-Path -Path $MigrationSettingsFilePath) $Site.SitePackagePath
            $SitePackagePath = $fullPkgPath
        }
        $AzureSiteName = $Site.AzureSiteName

        Send-TelemetryEventIfEnabled -TelemetryTitle "Invoke-SiteMigration.ps1" -EventName "Starting site migration" -EventType "info" -ErrorAction SilentlyContinue -Subscription $SubscriptionId -ResourceGroup $ResourceGroup -AzureSite $AzureSiteName
        Write-HostInfo "Migrating site '$IISSiteName' to Azure...."
        $SiteMigrationData = Invoke-SiteCreationAndDeployment -Region $Region -SubscriptionId $SubscriptionId -ResourceGroup $ResourceGroup -AppServicePlan $AppServicePlan -AppServiceEnvironment $AppServiceEnvironment -IISSiteName $IISSiteName -SitePackagePath $SitePackagePath -AzureSiteName $AzureSiteName        
        $script:ResourcesCreated += $SiteMigrationData
        Write-Host("") #cosmetic spacing
    }   
}


Write-AzureResourceResults -ResourceSummaryInfo $script:ResourcesCreated -MigrationResultsFilePath $MigrationResultsFilePath

Send-TelemetryEventIfEnabled -TelemetryTitle "Invoke-SiteMigration.ps1" -EventName "Script end" -EventType "action" -ErrorAction SilentlyContinue
return $script:ResourcesCreated



# SIG # Begin signature block
# MIIoLAYJKoZIhvcNAQcCoIIoHTCCKBkCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCCw8iWFkrE+ijtk
# 0B8itRtgs3w6/FAJecu0EOWQr3r+IaCCDXYwggX0MIID3KADAgECAhMzAAADrzBA
# DkyjTQVBAAAAAAOvMA0GCSqGSIb3DQEBCwUAMH4xCzAJBgNVBAYTAlVTMRMwEQYD
# VQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMTH01pY3Jvc29mdCBDb2RlIFNpZ25p
# bmcgUENBIDIwMTEwHhcNMjMxMTE2MTkwOTAwWhcNMjQxMTE0MTkwOTAwWjB0MQsw
# CQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9u
# ZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMR4wHAYDVQQDExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24wggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIB
# AQDOS8s1ra6f0YGtg0OhEaQa/t3Q+q1MEHhWJhqQVuO5amYXQpy8MDPNoJYk+FWA
# hePP5LxwcSge5aen+f5Q6WNPd6EDxGzotvVpNi5ve0H97S3F7C/axDfKxyNh21MG
# 0W8Sb0vxi/vorcLHOL9i+t2D6yvvDzLlEefUCbQV/zGCBjXGlYJcUj6RAzXyeNAN
# xSpKXAGd7Fh+ocGHPPphcD9LQTOJgG7Y7aYztHqBLJiQQ4eAgZNU4ac6+8LnEGAL
# go1ydC5BJEuJQjYKbNTy959HrKSu7LO3Ws0w8jw6pYdC1IMpdTkk2puTgY2PDNzB
# tLM4evG7FYer3WX+8t1UMYNTAgMBAAGjggFzMIIBbzAfBgNVHSUEGDAWBgorBgEE
# AYI3TAgBBggrBgEFBQcDAzAdBgNVHQ4EFgQURxxxNPIEPGSO8kqz+bgCAQWGXsEw
# RQYDVR0RBD4wPKQ6MDgxHjAcBgNVBAsTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEW
# MBQGA1UEBRMNMjMwMDEyKzUwMTgyNjAfBgNVHSMEGDAWgBRIbmTlUAXTgqoXNzci
# tW2oynUClTBUBgNVHR8ETTBLMEmgR6BFhkNodHRwOi8vd3d3Lm1pY3Jvc29mdC5j
# b20vcGtpb3BzL2NybC9NaWNDb2RTaWdQQ0EyMDExXzIwMTEtMDctMDguY3JsMGEG
# CCsGAQUFBwEBBFUwUzBRBggrBgEFBQcwAoZFaHR0cDovL3d3dy5taWNyb3NvZnQu
# Y29tL3BraW9wcy9jZXJ0cy9NaWNDb2RTaWdQQ0EyMDExXzIwMTEtMDctMDguY3J0
# MAwGA1UdEwEB/wQCMAAwDQYJKoZIhvcNAQELBQADggIBAISxFt/zR2frTFPB45Yd
# mhZpB2nNJoOoi+qlgcTlnO4QwlYN1w/vYwbDy/oFJolD5r6FMJd0RGcgEM8q9TgQ
# 2OC7gQEmhweVJ7yuKJlQBH7P7Pg5RiqgV3cSonJ+OM4kFHbP3gPLiyzssSQdRuPY
# 1mIWoGg9i7Y4ZC8ST7WhpSyc0pns2XsUe1XsIjaUcGu7zd7gg97eCUiLRdVklPmp
# XobH9CEAWakRUGNICYN2AgjhRTC4j3KJfqMkU04R6Toyh4/Toswm1uoDcGr5laYn
# TfcX3u5WnJqJLhuPe8Uj9kGAOcyo0O1mNwDa+LhFEzB6CB32+wfJMumfr6degvLT
# e8x55urQLeTjimBQgS49BSUkhFN7ois3cZyNpnrMca5AZaC7pLI72vuqSsSlLalG
# OcZmPHZGYJqZ0BacN274OZ80Q8B11iNokns9Od348bMb5Z4fihxaBWebl8kWEi2O
# PvQImOAeq3nt7UWJBzJYLAGEpfasaA3ZQgIcEXdD+uwo6ymMzDY6UamFOfYqYWXk
# ntxDGu7ngD2ugKUuccYKJJRiiz+LAUcj90BVcSHRLQop9N8zoALr/1sJuwPrVAtx
# HNEgSW+AKBqIxYWM4Ev32l6agSUAezLMbq5f3d8x9qzT031jMDT+sUAoCw0M5wVt
# CUQcqINPuYjbS1WgJyZIiEkBMIIHejCCBWKgAwIBAgIKYQ6Q0gAAAAAAAzANBgkq
# hkiG9w0BAQsFADCBiDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24x
# EDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlv
# bjEyMDAGA1UEAxMpTWljcm9zb2Z0IFJvb3QgQ2VydGlmaWNhdGUgQXV0aG9yaXR5
# IDIwMTEwHhcNMTEwNzA4MjA1OTA5WhcNMjYwNzA4MjEwOTA5WjB+MQswCQYDVQQG
# EwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwG
# A1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSgwJgYDVQQDEx9NaWNyb3NvZnQg
# Q29kZSBTaWduaW5nIFBDQSAyMDExMIICIjANBgkqhkiG9w0BAQEFAAOCAg8AMIIC
# CgKCAgEAq/D6chAcLq3YbqqCEE00uvK2WCGfQhsqa+laUKq4BjgaBEm6f8MMHt03
# a8YS2AvwOMKZBrDIOdUBFDFC04kNeWSHfpRgJGyvnkmc6Whe0t+bU7IKLMOv2akr
# rnoJr9eWWcpgGgXpZnboMlImEi/nqwhQz7NEt13YxC4Ddato88tt8zpcoRb0Rrrg
# OGSsbmQ1eKagYw8t00CT+OPeBw3VXHmlSSnnDb6gE3e+lD3v++MrWhAfTVYoonpy
# 4BI6t0le2O3tQ5GD2Xuye4Yb2T6xjF3oiU+EGvKhL1nkkDstrjNYxbc+/jLTswM9
# sbKvkjh+0p2ALPVOVpEhNSXDOW5kf1O6nA+tGSOEy/S6A4aN91/w0FK/jJSHvMAh
# dCVfGCi2zCcoOCWYOUo2z3yxkq4cI6epZuxhH2rhKEmdX4jiJV3TIUs+UsS1Vz8k
# A/DRelsv1SPjcF0PUUZ3s/gA4bysAoJf28AVs70b1FVL5zmhD+kjSbwYuER8ReTB
# w3J64HLnJN+/RpnF78IcV9uDjexNSTCnq47f7Fufr/zdsGbiwZeBe+3W7UvnSSmn
# Eyimp31ngOaKYnhfsi+E11ecXL93KCjx7W3DKI8sj0A3T8HhhUSJxAlMxdSlQy90
# lfdu+HggWCwTXWCVmj5PM4TasIgX3p5O9JawvEagbJjS4NaIjAsCAwEAAaOCAe0w
# ggHpMBAGCSsGAQQBgjcVAQQDAgEAMB0GA1UdDgQWBBRIbmTlUAXTgqoXNzcitW2o
# ynUClTAZBgkrBgEEAYI3FAIEDB4KAFMAdQBiAEMAQTALBgNVHQ8EBAMCAYYwDwYD
# VR0TAQH/BAUwAwEB/zAfBgNVHSMEGDAWgBRyLToCMZBDuRQFTuHqp8cx0SOJNDBa
# BgNVHR8EUzBRME+gTaBLhklodHRwOi8vY3JsLm1pY3Jvc29mdC5jb20vcGtpL2Ny
# bC9wcm9kdWN0cy9NaWNSb29DZXJBdXQyMDExXzIwMTFfMDNfMjIuY3JsMF4GCCsG
# AQUFBwEBBFIwUDBOBggrBgEFBQcwAoZCaHR0cDovL3d3dy5taWNyb3NvZnQuY29t
# L3BraS9jZXJ0cy9NaWNSb29DZXJBdXQyMDExXzIwMTFfMDNfMjIuY3J0MIGfBgNV
# HSAEgZcwgZQwgZEGCSsGAQQBgjcuAzCBgzA/BggrBgEFBQcCARYzaHR0cDovL3d3
# dy5taWNyb3NvZnQuY29tL3BraW9wcy9kb2NzL3ByaW1hcnljcHMuaHRtMEAGCCsG
# AQUFBwICMDQeMiAdAEwAZQBnAGEAbABfAHAAbwBsAGkAYwB5AF8AcwB0AGEAdABl
# AG0AZQBuAHQALiAdMA0GCSqGSIb3DQEBCwUAA4ICAQBn8oalmOBUeRou09h0ZyKb
# C5YR4WOSmUKWfdJ5DJDBZV8uLD74w3LRbYP+vj/oCso7v0epo/Np22O/IjWll11l
# hJB9i0ZQVdgMknzSGksc8zxCi1LQsP1r4z4HLimb5j0bpdS1HXeUOeLpZMlEPXh6
# I/MTfaaQdION9MsmAkYqwooQu6SpBQyb7Wj6aC6VoCo/KmtYSWMfCWluWpiW5IP0
# wI/zRive/DvQvTXvbiWu5a8n7dDd8w6vmSiXmE0OPQvyCInWH8MyGOLwxS3OW560
# STkKxgrCxq2u5bLZ2xWIUUVYODJxJxp/sfQn+N4sOiBpmLJZiWhub6e3dMNABQam
# ASooPoI/E01mC8CzTfXhj38cbxV9Rad25UAqZaPDXVJihsMdYzaXht/a8/jyFqGa
# J+HNpZfQ7l1jQeNbB5yHPgZ3BtEGsXUfFL5hYbXw3MYbBL7fQccOKO7eZS/sl/ah
# XJbYANahRr1Z85elCUtIEJmAH9AAKcWxm6U/RXceNcbSoqKfenoi+kiVH6v7RyOA
# 9Z74v2u3S5fi63V4GuzqN5l5GEv/1rMjaHXmr/r8i+sLgOppO6/8MO0ETI7f33Vt
# Y5E90Z1WTk+/gFcioXgRMiF670EKsT/7qMykXcGhiJtXcVZOSEXAQsmbdlsKgEhr
# /Xmfwb1tbWrJUnMTDXpQzTGCGgwwghoIAgEBMIGVMH4xCzAJBgNVBAYTAlVTMRMw
# EQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVN
# aWNyb3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMTH01pY3Jvc29mdCBDb2RlIFNp
# Z25pbmcgUENBIDIwMTECEzMAAAOvMEAOTKNNBUEAAAAAA68wDQYJYIZIAWUDBAIB
# BQCgga4wGQYJKoZIhvcNAQkDMQwGCisGAQQBgjcCAQQwHAYKKwYBBAGCNwIBCzEO
# MAwGCisGAQQBgjcCARUwLwYJKoZIhvcNAQkEMSIEIOD7xpZ9r0CzpMT5Ph/yyUnI
# zDb28Ws6e5rd5qpie542MEIGCisGAQQBgjcCAQwxNDAyoBSAEgBNAGkAYwByAG8A
# cwBvAGYAdKEagBhodHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20wDQYJKoZIhvcNAQEB
# BQAEggEAs0kBshXA+3G9QtMePV+wJjJTezHtnu1DJfyPMbFc7mo166hqJoseW3ty
# kbGGuNCQJqKmzh00ke13J7qhztKJ0mUhVUmzG88cKlGDLh1Fj561FJlWJNI8s1rE
# Il7v/0g1jAjf9nA03Xuw/CpT+CWG9QusAU5Gtz+pd1tcx5EtDMcCAG4dScM/jGLx
# r6cfbf5jbnMz11LEWEwChwy3rUOE7xdKFWpD4h+P6e2R89FtroxNOjgHNF1min0z
# Bi9WYzuDReb3NLxwzc2BBQwo8uu0VHMRlETCI96R02MbOKVUwC9U/dAPQxvaKNTR
# Zp3gjHPX75j7pkpjkZ8iA3pektacvqGCF5YwgheSBgorBgEEAYI3AwMBMYIXgjCC
# F34GCSqGSIb3DQEHAqCCF28wghdrAgEDMQ8wDQYJYIZIAWUDBAIBBQAwggFRBgsq
# hkiG9w0BCRABBKCCAUAEggE8MIIBOAIBAQYKKwYBBAGEWQoDATAxMA0GCWCGSAFl
# AwQCAQUABCAZ2quAUuvABXwBwm1boz8c21eQl0xHtlHRi2NsGumymQIGZaAVvDp4
# GBIyMDI0MDEyNTAwNDE0Ny4yNlowBIACAfSggdGkgc4wgcsxCzAJBgNVBAYTAlVT
# MRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQK
# ExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xJTAjBgNVBAsTHE1pY3Jvc29mdCBBbWVy
# aWNhIE9wZXJhdGlvbnMxJzAlBgNVBAsTHm5TaGllbGQgVFNTIEVTTjozNzAzLTA1
# RTAtRDk0NzElMCMGA1UEAxMcTWljcm9zb2Z0IFRpbWUtU3RhbXAgU2VydmljZaCC
# Ee0wggcgMIIFCKADAgECAhMzAAAB1OTpAy/ArGmsAAEAAAHUMA0GCSqGSIb3DQEB
# CwUAMHwxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQH
# EwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xJjAkBgNV
# BAMTHU1pY3Jvc29mdCBUaW1lLVN0YW1wIFBDQSAyMDEwMB4XDTIzMDUyNTE5MTIy
# N1oXDTI0MDIwMTE5MTIyN1owgcsxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNo
# aW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29y
# cG9yYXRpb24xJTAjBgNVBAsTHE1pY3Jvc29mdCBBbWVyaWNhIE9wZXJhdGlvbnMx
# JzAlBgNVBAsTHm5TaGllbGQgVFNTIEVTTjozNzAzLTA1RTAtRDk0NzElMCMGA1UE
# AxMcTWljcm9zb2Z0IFRpbWUtU3RhbXAgU2VydmljZTCCAiIwDQYJKoZIhvcNAQEB
# BQADggIPADCCAgoCggIBAJhT3i2bAiSXfndJZ6PXJtZxIBu7wUvBMS06/De5cylr
# UOcNcPBu2Qtz6hPwE22Ly37fxPCS1+CgAz038E4fJPgKlcHUfCfVhii+5i6OhBX2
# SbJToPpC21Mgo3t9lOOg20iEjkIGTBL4yTALB1o3LJK+PA+9m7EfxE1w44HwAEOE
# kf6/D+N6/4bbQcTQbBp3fbfHi4Di0uQTR73JoPvH+zUXeW3s2LjukkwYwuplAIrt
# QJR5Zq5YX3Bkg1Djn21I8h7/Erq20vJgfN3cN5FEvFA//tzug8k8MWClsYHYdElo
# TSm5FEOiIM/sknFiv5METGEja6VlZuAvgJ9ZrDBvUuwmYVYkduoavqjSKtbsioOR
# /aoRsxFPVZQzXkXmgFzkuDXyVvexRbuRE+8rCZ9pEGSuaKXQf+2/cdjIToDj3RkU
# Rw+Tp3NgAp8J7e8qlFUTh0+gMpWcItRMuSrV/+me4P9kYcnZxu4h6v26ZBi78XPU
# MGt4LwJGzfMmbjwchLett4tRi78L3eNUgk6WsoC/+qZhHKaMOal/Nm9+8YEZRs6n
# H7ih/CoFMu6EB87sVnPffw22yMPOreyJHRw/vin1S41fVOnPgpkszwaXNkuN7dod
# 8Pea6Ws8gyKmdWoGSRjXZrayWxsiWN7e6rwFKuPvbn/AcK3gfJdbhaBMY+LPITFN
# AgMBAAGjggFJMIIBRTAdBgNVHQ4EFgQUPNqMx3C0BnoSgHkd51yyu7QMdkkwHwYD
# VR0jBBgwFoAUn6cVXQBeYl2D9OXSZacbUzUZ6XIwXwYDVR0fBFgwVjBUoFKgUIZO
# aHR0cDovL3d3dy5taWNyb3NvZnQuY29tL3BraW9wcy9jcmwvTWljcm9zb2Z0JTIw
# VGltZS1TdGFtcCUyMFBDQSUyMDIwMTAoMSkuY3JsMGwGCCsGAQUFBwEBBGAwXjBc
# BggrBgEFBQcwAoZQaHR0cDovL3d3dy5taWNyb3NvZnQuY29tL3BraW9wcy9jZXJ0
# cy9NaWNyb3NvZnQlMjBUaW1lLVN0YW1wJTIwUENBJTIwMjAxMCgxKS5jcnQwDAYD
# VR0TAQH/BAIwADAWBgNVHSUBAf8EDDAKBggrBgEFBQcDCDAOBgNVHQ8BAf8EBAMC
# B4AwDQYJKoZIhvcNAQELBQADggIBALTFQ8/7K3CS11GFiVn0GTj9svMs7Or7BwLt
# UBpFAcZFL4g/JT/w4uJWhdyjIooqJFDsr1z3Q50z6ovg+LMqdK0sMGxZP52zWFrI
# 2RPCeFVxl4DUQYqU1m92VOwJTEnkLvKhlCYD7aWmTTg8aNwWEfWAZGmHP61wM0r8
# K0on4+sS42PuyCYGin8kVBxjKaI/++v5252spB5K1xNX1bXdybYUPkX9dY7ftOL4
# bhODUGRTblED63xEJbL8ge6DeutjOpRx1VGrtSBGXjRgiRM2e5yjqfLu8QGZYWNy
# vtKS+j9Ba547w0C8/Zkp/dAx+J2YfXG/HH2H3BVTqu8RD89QmLemiliytAq6iCmF
# 0+odnmP06hD4SMAJR+AmUeefwZVs9bfEamUKRdvIQeF5A139rdf/bOlLARE45zLV
# hp5Cq5+UaKUB/TLjQAUqpbZDXJNvX1xFcGlHNtlU75FdQHgDpQvUTVeO3Ov9v2rP
# 1ThQ1XzDLxi//TtuneEAV/EHiafRz4875gW/ZixW9gBNUjaXAv1ANIS3wXRFbot6
# TE9+9uSZVJHA/ql/kBR+Sqigprql+pMKd2kZPvUfKKW16VoyFFSw1WRorMAmtSgR
# JKPuxM/VkaJL0mAj6ncA7l+cyG3eYscyDrwazNIfhbLe9QMmmNRNgu1pNaRC3PpS
# pk83tZeGMIIHcTCCBVmgAwIBAgITMwAAABXF52ueAptJmQAAAAAAFTANBgkqhkiG
# 9w0BAQsFADCBiDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAO
# BgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEy
# MDAGA1UEAxMpTWljcm9zb2Z0IFJvb3QgQ2VydGlmaWNhdGUgQXV0aG9yaXR5IDIw
# MTAwHhcNMjEwOTMwMTgyMjI1WhcNMzAwOTMwMTgzMjI1WjB8MQswCQYDVQQGEwJV
# UzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UE
# ChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSYwJAYDVQQDEx1NaWNyb3NvZnQgVGlt
# ZS1TdGFtcCBQQ0EgMjAxMDCCAiIwDQYJKoZIhvcNAQEBBQADggIPADCCAgoCggIB
# AOThpkzntHIhC3miy9ckeb0O1YLT/e6cBwfSqWxOdcjKNVf2AX9sSuDivbk+F2Az
# /1xPx2b3lVNxWuJ+Slr+uDZnhUYjDLWNE893MsAQGOhgfWpSg0S3po5GawcU88V2
# 9YZQ3MFEyHFcUTE3oAo4bo3t1w/YJlN8OWECesSq/XJprx2rrPY2vjUmZNqYO7oa
# ezOtgFt+jBAcnVL+tuhiJdxqD89d9P6OU8/W7IVWTe/dvI2k45GPsjksUZzpcGkN
# yjYtcI4xyDUoveO0hyTD4MmPfrVUj9z6BVWYbWg7mka97aSueik3rMvrg0XnRm7K
# MtXAhjBcTyziYrLNueKNiOSWrAFKu75xqRdbZ2De+JKRHh09/SDPc31BmkZ1zcRf
# NN0Sidb9pSB9fvzZnkXftnIv231fgLrbqn427DZM9ituqBJR6L8FA6PRc6ZNN3SU
# HDSCD/AQ8rdHGO2n6Jl8P0zbr17C89XYcz1DTsEzOUyOArxCaC4Q6oRRRuLRvWoY
# WmEBc8pnol7XKHYC4jMYctenIPDC+hIK12NvDMk2ZItboKaDIV1fMHSRlJTYuVD5
# C4lh8zYGNRiER9vcG9H9stQcxWv2XFJRXRLbJbqvUAV6bMURHXLvjflSxIUXk8A8
# FdsaN8cIFRg/eKtFtvUeh17aj54WcmnGrnu3tz5q4i6tAgMBAAGjggHdMIIB2TAS
# BgkrBgEEAYI3FQEEBQIDAQABMCMGCSsGAQQBgjcVAgQWBBQqp1L+ZMSavoKRPEY1
# Kc8Q/y8E7jAdBgNVHQ4EFgQUn6cVXQBeYl2D9OXSZacbUzUZ6XIwXAYDVR0gBFUw
# UzBRBgwrBgEEAYI3TIN9AQEwQTA/BggrBgEFBQcCARYzaHR0cDovL3d3dy5taWNy
# b3NvZnQuY29tL3BraW9wcy9Eb2NzL1JlcG9zaXRvcnkuaHRtMBMGA1UdJQQMMAoG
# CCsGAQUFBwMIMBkGCSsGAQQBgjcUAgQMHgoAUwB1AGIAQwBBMAsGA1UdDwQEAwIB
# hjAPBgNVHRMBAf8EBTADAQH/MB8GA1UdIwQYMBaAFNX2VsuP6KJcYmjRPZSQW9fO
# mhjEMFYGA1UdHwRPME0wS6BJoEeGRWh0dHA6Ly9jcmwubWljcm9zb2Z0LmNvbS9w
# a2kvY3JsL3Byb2R1Y3RzL01pY1Jvb0NlckF1dF8yMDEwLTA2LTIzLmNybDBaBggr
# BgEFBQcBAQROMEwwSgYIKwYBBQUHMAKGPmh0dHA6Ly93d3cubWljcm9zb2Z0LmNv
# bS9wa2kvY2VydHMvTWljUm9vQ2VyQXV0XzIwMTAtMDYtMjMuY3J0MA0GCSqGSIb3
# DQEBCwUAA4ICAQCdVX38Kq3hLB9nATEkW+Geckv8qW/qXBS2Pk5HZHixBpOXPTEz
# tTnXwnE2P9pkbHzQdTltuw8x5MKP+2zRoZQYIu7pZmc6U03dmLq2HnjYNi6cqYJW
# AAOwBb6J6Gngugnue99qb74py27YP0h1AdkY3m2CDPVtI1TkeFN1JFe53Z/zjj3G
# 82jfZfakVqr3lbYoVSfQJL1AoL8ZthISEV09J+BAljis9/kpicO8F7BUhUKz/Aye
# ixmJ5/ALaoHCgRlCGVJ1ijbCHcNhcy4sa3tuPywJeBTpkbKpW99Jo3QMvOyRgNI9
# 5ko+ZjtPu4b6MhrZlvSP9pEB9s7GdP32THJvEKt1MMU0sHrYUP4KWN1APMdUbZ1j
# dEgssU5HLcEUBHG/ZPkkvnNtyo4JvbMBV0lUZNlz138eW0QBjloZkWsNn6Qo3GcZ
# KCS6OEuabvshVGtqRRFHqfG3rsjoiV5PndLQTHa1V1QJsWkBRH58oWFsc/4Ku+xB
# Zj1p/cvBQUl+fpO+y/g75LcVv7TOPqUxUYS8vwLBgqJ7Fx0ViY1w/ue10CgaiQuP
# Ntq6TPmb/wrpNPgkNWcr4A245oyZ1uEi6vAnQj0llOZ0dFtq0Z4+7X6gMTN9vMvp
# e784cETRkPHIqzqKOghif9lwY1NNje6CbaUFEMFxBmoQtB1VM1izoXBm8qGCA1Aw
# ggI4AgEBMIH5oYHRpIHOMIHLMQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGlu
# Z3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBv
# cmF0aW9uMSUwIwYDVQQLExxNaWNyb3NvZnQgQW1lcmljYSBPcGVyYXRpb25zMScw
# JQYDVQQLEx5uU2hpZWxkIFRTUyBFU046MzcwMy0wNUUwLUQ5NDcxJTAjBgNVBAMT
# HE1pY3Jvc29mdCBUaW1lLVN0YW1wIFNlcnZpY2WiIwoBATAHBgUrDgMCGgMVAC0z
# XZaOjbHEDmx27MH/cd3NmaJIoIGDMIGApH4wfDELMAkGA1UEBhMCVVMxEzARBgNV
# BAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jv
# c29mdCBDb3Jwb3JhdGlvbjEmMCQGA1UEAxMdTWljcm9zb2Z0IFRpbWUtU3RhbXAg
# UENBIDIwMTAwDQYJKoZIhvcNAQELBQACBQDpW7caMCIYDzIwMjQwMTI0MTYxOTM4
# WhgPMjAyNDAxMjUxNjE5MzhaMHcwPQYKKwYBBAGEWQoEATEvMC0wCgIFAOlbtxoC
# AQAwCgIBAAICAOECAf8wBwIBAAICEykwCgIFAOldCJoCAQAwNgYKKwYBBAGEWQoE
# AjEoMCYwDAYKKwYBBAGEWQoDAqAKMAgCAQACAwehIKEKMAgCAQACAwGGoDANBgkq
# hkiG9w0BAQsFAAOCAQEAZpXk+uo01fpuhaP7MmSOIMUH1ckgR6DeavSiVtyb6Dgy
# /66j/Skn64+4b+EXfarD+3BpjRSysqLVDgMTSoufwrfwlODMZIjSqbDCduyKLOU/
# 5LChI1n3/BKAg1J+5FVqrMUxZlXJTI+6AjMmrNcZA5WIVB3aEWAffQAIrDjy/RV7
# Fhdm1/4towS/ZoFdgo/VZbRIc1j/FYQbgEPvrlV4p5jjODl4CtpyBCUheWiy8wL/
# 3JVV2hULA4WBagxl48E/Zn19wO5nFyczHrUfjbShI3JQC7db9DXg4fddNVOg5Fxn
# B77wh0f1SrRs36mTaMITSTCFP08xCFZnFBx747sSzDGCBA0wggQJAgEBMIGTMHwx
# CzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRt
# b25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xJjAkBgNVBAMTHU1p
# Y3Jvc29mdCBUaW1lLVN0YW1wIFBDQSAyMDEwAhMzAAAB1OTpAy/ArGmsAAEAAAHU
# MA0GCWCGSAFlAwQCAQUAoIIBSjAaBgkqhkiG9w0BCQMxDQYLKoZIhvcNAQkQAQQw
# LwYJKoZIhvcNAQkEMSIEII2FvISLQqMEQrNX2+EJHO3TEsozf/QcezaBMIrULW0G
# MIH6BgsqhkiG9w0BCRACLzGB6jCB5zCB5DCBvQQgzOqH+tgUpc6XO9ZLnEK0+L1p
# T58FSTEiuJenZZM9YjcwgZgwgYCkfjB8MQswCQYDVQQGEwJVUzETMBEGA1UECBMK
# V2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0
# IENvcnBvcmF0aW9uMSYwJAYDVQQDEx1NaWNyb3NvZnQgVGltZS1TdGFtcCBQQ0Eg
# MjAxMAITMwAAAdTk6QMvwKxprAABAAAB1DAiBCASiRxNpigBJPnKMNupJ1z7RmpM
# k1oqPRT495wb9+gr1DANBgkqhkiG9w0BAQsFAASCAgB1xCtLNX2jaRtUynwK4gZ+
# 0UjvBZkrF79v8FvV6nt3QMtXjVUElPrKU4hg8NuPy8D45kt0gPHVRqxJARsGJbDS
# 41trTra3YZrP9p6NW3Fg6444VjpYtdb1PW6QvZ0bDa34P5/LrzsW/TgwQOUotGDf
# m+Cy2Q9Ma+ZJ+njNLiXa2ErKeCTYvGYsQ9Fqrd8wZQ9LaOv55Rl9+TDOODxL7vpE
# oak9546s0+ysMDFwneFwoyA0De5vDVWKq0Ty6k9x8dmUeOgn9zjA09pvp3kn/N2g
# uwquL2WZUso3nbyddydAQkkEHRy4wy0WgFQqv7jE/QET79etm0Gtwp8jNBylIVuR
# UQETL2FStdVDOK+bRXlnAnaTw3bf78aQysIgkfuMmuoRtKSzPe1AdH4BXjcM9NmO
# KPtn/+4XmVS8YTy6ZMhg8N8m/C0isMDNOp7xovizjqZVq8pgXGu8oCRSplJa3rsG
# +Rgk1h7l4CxcV7u8qnhsBJBQm/1/RmCVILj5M8qC8V6IKwUCFKlw/BX3N0dyspWu
# QiJxPjM39Nd8MMQMBsL5ejZJE8/x50ke7RBLsBaOn0DDQI5IoNq5B6OJIQ33xKRt
# R20e7JRTEfNF5ziOBlcKsXcbc9XyS57whmbkF/REc83LdbMOnoxrDIicaP7Fekwv
# kEHmGeCalW3+OTGyWIgYng==
# SIG # End signature block
